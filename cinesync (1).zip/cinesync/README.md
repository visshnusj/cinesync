# CineSync – Indian Movie Ticket Booking & Seasonal Theatre Management

React (Vite) + Node/Express + MySQL. Light-themed UI. Everything runs from VS Code.

## Requirements
- Node.js 18+ and npm
- MySQL 8 (or MariaDB 10.6+) running locally

## Install & run (VS Code)
1. Open the `cinesync` folder in VS Code (File → Open Folder).
2. Edit `server/.env` and set `DB_PASSWORD` to your MySQL root password (change `DB_USER` if needed).
3. Open a terminal (Ctrl+`) in the project root and run:
   ```
   npm install
   npm run setup      # installs server + client packages
   npm run seed       # creates DB "cinesync", all tables, states/UTs, languages, genres, admin, sample theatre
   npm run dev        # starts API (http://localhost:5000) and website (http://localhost:5173)
   ```
   (Or use two terminals: `cd server && npm run dev` and `cd client && npm run dev`.)
4. Open http://localhost:5173

## Test logins
| Role | Email | Password |
|---|---|---|
| Admin (http://localhost:5173/admin) | admin@cinesync.in | Admin@123 |
| Customer | customer@cinesync.in | Customer@123 |

## First-run walkthrough (testing)
1. Admin → **Movies** → add a movie (poster upload is required), pick original/dubbed languages, genres, and assign to the sample theatre "CineSync Cinemas Trichy".
2. Admin → **Seasonal Timings**: seasons and opening hours are pre-seeded for the sample theatre (edit/add your own; overlapping seasons per theatre are rejected).
3. Admin → **Shows** → *Generate*: choose movie, theatre and a date range. Up to 5 shows/day per screen are created inside the active season's hours using movie duration + 20 min cleaning gap. Overlaps on a screen are skipped/rejected.
4. Customer site → choose Tamil Nadu → Tiruchirappalli → Tiruchirappalli, open the movie, book seats, view the ticket.
5. After booking, the customer can post a verified review on the movie page (right column on desktop). Admin → **Reviews** can hide/restore (never edit) reviews.
6. Admin → **Dashboard** shows live counts, charts and show-wise occupancy with state/district/city/theatre/movie/date/time filters.

## Folder structure
```
cinesync/
  server/  db/schema.sql  db/seed.js  uploads/ (posters)
           src/index.js  src/db.js  src/lib.js  src/shows.js
           src/routes/public.js (auth, locations, movies, shows, bookings, reviews)
           src/routes/admin.js  (master data, theatres, seasons, movies, shows, reviews, stats)
  client/  src/App.jsx api.jsx components.jsx styles.css
           src/pages/ Home, MovieDetails, Booking, Account, Login
           src/pages/admin/ Dashboard, MoviesTheatres, SeasonsShows, Others, AdminLayout
```

## Main API endpoints
Public/customer (`/api`): `POST /auth/register|login|admin-login`, `GET /locations/states|districts|cities`, `GET /meta`, `GET /theatres`,
`GET /movies`, `GET /movies/:id`, `GET /movies/:id/dates`, `GET|POST|PUT|DELETE /movies/:id/reviews`, `GET /movies/:id/my-review`,
`GET /shows`, `GET /shows/:id/seats`, `POST /bookings`, `GET /me/bookings[/:code]`, `POST /me/bookings/:code/cancel`.

Admin (`/api/admin`, admin JWT required): `districts, cities, languages, genres (POST)`, `theatres (CRUD) + /theatres/:id/screens`, `screens/:id`,
`seasons (CRUD)`, `schedules (POST/DELETE)`, `movies (CRUD, multipart poster)`, `shows (GET, PUT, DELETE) + /shows/generate`,
`reviews (GET) + /reviews/:id/status`, `customers`, `stats` (filters: stateId, districtId, cityId, theatreId, movieId, date, showTime).

## Notes
- Double booking is prevented by a MySQL transaction (`SELECT … FOR UPDATE` on the show) plus a UNIQUE(show_id, seat_id) key.
- Cancelling a booking frees its seats and marks the payment refunded. Payment is simulated (recorded in `payments`).
- All 28 states and 8 UTs are preloaded with starter districts/cities (not all ~780 districts). Add more in **Locations & Master Data**.
- No fake ratings/reviews exist: all come from the database.
