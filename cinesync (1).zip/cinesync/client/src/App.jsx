import React from 'react';
import { Routes, Route, Navigate, Link, useLocation } from 'react-router-dom';
import { Film, LogOut, User } from 'lucide-react';
import { useAuth } from './api.jsx';
import Home from './pages/Home.jsx';
import MovieDetails from './pages/MovieDetails.jsx';
import Booking from './pages/Booking.jsx';
import { Confirmation, MyBookings } from './pages/Account.jsx';
import { Login, Register } from './pages/Login.jsx';
import AdminLayout from './pages/admin/AdminLayout.jsx';

function Navbar() {
  const { auth, logout } = useAuth();
  return (
    <header className="nav">
      <Link to="/" className="brand"><Film size={22} /> Cine<b>Sync</b></Link>
      <div className="row">
        {auth?.role === 'user' ? <>
          <Link to="/my-bookings" className="btn ghost"><User size={15} /> {auth.name}</Link>
          <button className="btn ghost" onClick={logout}><LogOut size={15} /> Logout</button></>
          : <><Link to="/login" className="btn ghost">Login</Link><Link to="/register" className="btn">Sign up</Link></>}
        <Link to="/admin" className="muted small">Admin</Link>
      </div>
    </header>
  );
}

export default function App() {
  const { pathname } = useLocation();
  const admin = pathname.startsWith('/admin');
  return (
    <>
      {!admin && <Navbar />}
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/movie/:id" element={<MovieDetails />} />
        <Route path="/book/:id" element={<Booking />} />
        <Route path="/confirmation/:code" element={<Confirmation />} />
        <Route path="/my-bookings" element={<MyBookings />} />
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route path="/admin/*" element={<AdminLayout />} />
        <Route path="*" element={<Navigate to="/" />} />
      </Routes>
    </>
  );
}
