import React, { createContext, useContext, useState, useEffect } from 'react';

export async function api(path, { method = 'GET', body, form } = {}) {
  const a = JSON.parse(localStorage.getItem('cs_auth') || 'null');
  const headers = {};
  if (a) headers.Authorization = 'Bearer ' + a.token;
  if (body) headers['Content-Type'] = 'application/json';
  const r = await fetch('/api' + path, { method, headers, body: form || (body ? JSON.stringify(body) : undefined) });
  const data = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(data.error || 'Request failed');
  return data;
}
export const qs = (o) => new URLSearchParams(Object.fromEntries(Object.entries(o).filter(([, v]) => v !== '' && v != null))).toString();

export function useApi(path, deps = []) {
  const [data, setData] = useState(null); const [err, setErr] = useState('');
  const [tick, setTick] = useState(0);
  useEffect(() => { if (path === null) return; let live = true; setErr('');
    api(path).then((d) => live && setData(d)).catch((e) => live && setErr(e.message)); return () => { live = false; }; }, [path, tick, ...deps]);
  return [data, err, () => setTick((t) => t + 1)];
}

const Ctx = createContext();
export const useAuth = () => useContext(Ctx);
export function AuthProvider({ children }) {
  const [auth, setAuth] = useState(JSON.parse(localStorage.getItem('cs_auth') || 'null'));
  const login = (d) => { localStorage.setItem('cs_auth', JSON.stringify(d)); setAuth(d); };
  const logout = () => { localStorage.removeItem('cs_auth'); setAuth(null); };
  return <Ctx.Provider value={{ auth, login, logout }}>{children}</Ctx.Provider>;
}
export const money = (n) => '₹' + Number(n).toLocaleString('en-IN');
export const fmtTime = (s) => new Date(s.replace(' ', 'T')).toLocaleTimeString('en-IN', { hour: 'numeric', minute: '2-digit', hour12: true });
export const fmtDate = (s) => new Date(s.replace(' ', 'T')).toLocaleDateString('en-IN', { weekday: 'short', day: 'numeric', month: 'short', year: 'numeric' });
