import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Star, ChevronLeft, ChevronRight } from 'lucide-react';
import { api } from './api.jsx';

export const Stars = ({ value = 0, size = 16, onChange }) => (
  <span className="stars">{[1, 2, 3, 4, 5].map((i) => (
    <Star key={i} size={size} className={i <= Math.round(value) ? 'on' : ''} onClick={onChange ? () => onChange(i) : undefined} style={onChange ? { cursor: 'pointer' } : {}} />))}</span>
);
export const Msg = ({ text, ok }) => text ? <div className={'msg ' + (ok ? 'ok' : 'err')}>{text}</div> : null;

export function MovieCard({ m }) {
  const orig = m.languages.find((l) => l.type === 'original');
  return (
    <Link to={`/movie/${m.movie_id}`} className="card movie-card">
      <img src={m.poster_url} alt={m.title} loading="lazy" />
      <div className="mc-body">
        <h4>{m.title}</h4>
        <div className="rate">{m.review_count ? <><Stars value={m.avg_rating} size={13} /> <b>{m.avg_rating}</b> <span className="muted">({m.review_count})</span></> : <span className="muted">No reviews yet</span>}</div>
        <div className="muted small">{orig?.name}{m.languages.length > 1 ? ` • +${m.languages.length - 1} dubbed` : ''} • {m.certification || 'NR'}</div>
        <div className="tags">{m.genres.slice(0, 3).map((g) => <span key={g.id} className="tag">{g.name}</span>)}</div>
      </div>
    </Link>
  );
}

// Country -> State/UT -> District -> City selector (data from MySQL)
export function LocationPicker({ value, onChange, compact }) {
  const [states, setS] = useState([]); const [dists, setD] = useState([]); const [cities, setC] = useState([]);
  useEffect(() => { api('/locations/states').then(setS); }, []);
  useEffect(() => { value.stateId ? api('/locations/districts?stateId=' + value.stateId).then(setD) : setD([]); }, [value.stateId]);
  useEffect(() => { value.districtId ? api('/locations/cities?districtId=' + value.districtId).then(setC) : setC([]); }, [value.districtId]);
  return (
    <div className={'row wrap ' + (compact ? 'compact' : '')}>
      <select disabled><option>India</option></select>
      <select value={value.stateId || ''} onChange={(e) => onChange({ stateId: e.target.value, districtId: '', cityId: '' })}>
        <option value="">State / UT</option>{states.map((s) => <option key={s.state_id} value={s.state_id}>{s.name}</option>)}</select>
      <select value={value.districtId || ''} disabled={!value.stateId} onChange={(e) => onChange({ ...value, districtId: e.target.value, cityId: '' })}>
        <option value="">District</option>{dists.map((s) => <option key={s.district_id} value={s.district_id}>{s.name}</option>)}</select>
      <select value={value.cityId || ''} disabled={!value.districtId} onChange={(e) => onChange({ ...value, cityId: e.target.value })}>
        <option value="">City</option>{cities.map((s) => <option key={s.city_id} value={s.city_id}>{s.name}</option>)}</select>
    </div>
  );
}
export function useLoc() {
  const [loc, set] = useState(JSON.parse(localStorage.getItem('cs_loc') || '{}'));
  return [loc, (v) => { localStorage.setItem('cs_loc', JSON.stringify(v)); set(v); }];
}

// Calendar that only enables dates present in `enabled` (array of YYYY-MM-DD)
export function Calendar({ enabled, value, onChange }) {
  const first = enabled[0] ? new Date(enabled[0] + 'T00:00:00') : new Date();
  const [cur, setCur] = useState(new Date(first.getFullYear(), first.getMonth(), 1));
  useEffect(() => { setCur(new Date(first.getFullYear(), first.getMonth(), 1)); }, [enabled.join()]);
  const y = cur.getFullYear(), mo = cur.getMonth(); const days = new Date(y, mo + 1, 0).getDate(); const lead = cur.getDay();
  const iso = (d) => `${y}-${String(mo + 1).padStart(2, '0')}-${String(d).padStart(2, '0')}`;
  return (
    <div className="cal">
      <div className="cal-head"><button className="icon" onClick={() => setCur(new Date(y, mo - 1, 1))}><ChevronLeft size={16} /></button>
        <b>{cur.toLocaleString('en-IN', { month: 'long', year: 'numeric' })}</b>
        <button className="icon" onClick={() => setCur(new Date(y, mo + 1, 1))}><ChevronRight size={16} /></button></div>
      <div className="cal-grid">{'SMTWTFS'.split('').map((d, i) => <span key={i} className="muted small">{d}</span>)}
        {Array.from({ length: lead }, (_, i) => <span key={'e' + i} />)}
        {Array.from({ length: days }, (_, i) => { const d = iso(i + 1); const ok = enabled.includes(d);
          return <button key={d} disabled={!ok} className={'day ' + (value === d ? 'sel' : '')} onClick={() => onChange(d)}>{i + 1}</button>; })}</div>
    </div>
  );
}
