import React, { useState } from 'react';
import { useParams, Link, Navigate } from 'react-router-dom';
import { CheckCircle2 } from 'lucide-react';
import { api, useApi, useAuth, money, fmtTime, fmtDate } from '../api.jsx';
import { Msg } from '../components.jsx';

export function Confirmation() {
  const { code } = useParams(); const [b, err] = useApi('/me/bookings/' + code);
  if (err) return <div className="wrap"><Msg text={err} /></div>;
  if (!b) return <div className="wrap muted">Loading…</div>;
  return (
    <main className="wrap"><div className="card ticket">
      <div className="center"><CheckCircle2 size={42} color="#16a34a" /><h2>Booking confirmed</h2><div className="code">{b.booking_code}</div></div>
      <div className="row"><img src={b.poster_url} className="thumb" alt="" /><div>
        <h3>{b.title}</h3><div>{b.theatre}, {b.city}</div><div className="muted small">{b.address}</div>
        <div><b>{fmtDate(b.start_at)} • {fmtTime(b.start_at)}</b> • Screen {b.screen_no}</div>
        <div>Seats: <b>{b.seats}</b></div><div>Paid: <b>{money(b.total_amount)}</b></div></div></div>
      <div className="row center"><Link to="/my-bookings" className="btn ghost">My bookings</Link><button className="btn ghost" onClick={() => window.print()}>Print ticket</button><Link to="/" className="btn">Home</Link></div>
    </div></main>
  );
}

export function MyBookings() {
  const { auth } = useAuth(); const [list, err, reload] = useApi(auth?.role === 'user' ? '/me/bookings' : null, [auth]); const [msg, setMsg] = useState('');
  if (auth?.role !== 'user') return <Navigate to="/login" />;
  const cancel = async (code) => { if (!confirm('Cancel this booking?')) return; try { await api(`/me/bookings/${code}/cancel`, { method: 'POST' }); reload(); } catch (e) { setMsg(e.message); } };
  return (
    <main className="wrap"><h2>My bookings</h2><Msg text={err || msg} />
      {list && !list.length && <p className="muted">No bookings yet.</p>}
      {list?.map((b) => (
        <div key={b.booking_id} className="card pad row between wrap-sm">
          <div className="row"><img src={b.poster_url} className="thumb" alt="" /><div>
            <Link to={`/movie/${b.movie_id}`}><b>{b.title}</b></Link><div className="small">{b.theatre}, {b.city} • Screen {b.screen_no}</div>
            <div className="small">{fmtDate(b.start_at)} {fmtTime(b.start_at)} • Seats {b.seats || '—'}</div>
            <div className="small">{b.booking_code} • {money(b.total_amount)} <span className={'tag ' + (b.status === 'confirmed' ? 'ok' : 'bad')}>{b.status}</span></div></div></div>
          <div className="row">
            {b.status === 'confirmed' && <Link className="btn ghost" to={`/confirmation/${b.booking_code}`}>Ticket</Link>}
            {b.status === 'confirmed' && <Link className="btn ghost" to={`/movie/${b.movie_id}`}>Review</Link>}
            {b.status === 'confirmed' && b.upcoming ? <button className="btn danger" onClick={() => cancel(b.booking_code)}>Cancel</button> : null}</div>
        </div>))}
    </main>
  );
}
