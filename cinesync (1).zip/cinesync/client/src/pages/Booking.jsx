import React, { useState, useEffect } from 'react';
import { useParams, useSearchParams, useNavigate, Navigate } from 'react-router-dom';
import { api, useApi, useAuth, money, fmtTime, fmtDate } from '../api.jsx';
import { Calendar, Msg } from '../components.jsx';

export default function Booking() {
  const { id } = useParams(); const [sp] = useSearchParams(); const nav = useNavigate(); const { auth } = useAuth();
  const [m] = useApi('/movies/' + id);
  const [theatreId, setTheatreId] = useState(sp.get('theatre') || '');
  const [date, setDate] = useState(''); const [showId, setShowId] = useState(''); const [picked, setPicked] = useState([]);
  const [err, setErr] = useState(''); const [busy, setBusy] = useState(false); const [method, setMethod] = useState('UPI');
  const [dates] = useApi(theatreId ? `/movies/${id}/dates?theatreId=${theatreId}` : null, [theatreId]);
  const [shows] = useApi(theatreId && date ? `/shows?movieId=${id}&theatreId=${theatreId}&date=${date}` : null, [theatreId, date]);
  const [layout, , reloadSeats] = useApi(showId ? `/shows/${showId}/seats` : null, [showId]);
  useEffect(() => { if (m && !theatreId && m.theatres.length === 1) setTheatreId(String(m.theatres[0].theatre_id)); }, [m]);
  useEffect(() => { setDate(''); setShowId(''); }, [theatreId]);
  useEffect(() => { setShowId(''); }, [date]);
  useEffect(() => { setPicked([]); }, [showId]);
  if (auth?.role !== 'user') return <Navigate to="/login" state={{ from: `/book/${id}` }} />;
  if (!m) return <div className="wrap muted">Loading…</div>;

  const rows = {}; layout?.seats.forEach((s) => (rows[s.row_label] ||= []).push(s));
  const toggle = (s) => !s.booked && setPicked((p) => p.includes(s.seat_id) ? p.filter((x) => x !== s.seat_id) : p.length < 10 ? [...p, s.seat_id] : p);
  const status = (s) => { const left = s.capacity - s.booked, pct = (s.booked / s.capacity) * 100; return left === 0 ? ['Sold out', 'bad'] : pct >= 70 ? ['Filling fast', 'warn'] : ['Available', 'ok']; };
  const confirm = async () => {
    setBusy(true); setErr('');
    try { const r = await api('/bookings', { method: 'POST', body: { showId, seatIds: picked, paymentMethod: method } }); nav('/confirmation/' + r.bookingCode); }
    catch (e) { setErr(e.message); setPicked([]); reloadSeats(); } finally { setBusy(false); }
  };

  return (
    <main className="wrap">
      <div className="row"><img src={m.poster_url} alt="" className="thumb" /><div><h2>{m.title}</h2><div className="muted small">Choose theatre → date → show → seats</div></div></div>
      <h3>1. Theatre</h3>
      <select value={theatreId} onChange={(e) => setTheatreId(e.target.value)}><option value="">Select theatre</option>{m.theatres.map((t) => <option key={t.theatre_id} value={t.theatre_id}>{t.name} — {t.city}, {t.state}</option>)}</select>
      {theatreId && <><h3>2. Date</h3>{dates?.length ? <Calendar enabled={dates} value={date} onChange={setDate} /> : <p className="muted">No upcoming shows scheduled at this theatre.</p>}</>}
      {date && <><h3>3. Show time — {fmtDate(date + ' 00:00')}</h3>
        <div className="shows">{shows?.map((s) => { const [label, cls] = status(s); const dis = s.past || s.booked >= s.capacity;
          return <button key={s.show_id} disabled={dis} className={'card show ' + (showId == s.show_id ? 'sel' : '')} onClick={() => setShowId(s.show_id)}>
            <b>{fmtTime(s.start_at)}</b><span className="small">{s.theatre} • Screen {s.screen_no}</span><span>{money(s.price)}</span>
            <span className="small">{s.capacity - s.booked} seats left</span><span className={'tag ' + cls}>{s.past ? 'Started' : label}</span></button>; })}
          {shows && !shows.length && <p className="muted">No shows on this date.</p>}</div></>}
      {layout && <><h3>4. Seats</h3>
        <div className="screen">SCREEN THIS WAY</div>
        <div className="seatmap">{Object.entries(rows).map(([r, ss]) => <div key={r} className="seatrow"><span className="rl">{r}</span>
          {ss.map((s) => <button key={s.seat_id} title={r + s.seat_number} className={'seat ' + (s.booked ? 'booked' : picked.includes(s.seat_id) ? 'picked' : '')} disabled={!!s.booked} onClick={() => toggle(s)}>{s.seat_number}</button>)}</div>)}</div>
        <div className="legend"><span><i className="seat" /> Available</span><span><i className="seat picked" /> Selected</span><span><i className="seat booked" /> Booked</span></div>
        <div className="card pad checkout"><div><b>{picked.length}</b> seat(s) • Total <b>{money(picked.length * Number(layout.show.price))}</b></div>
          <select value={method} onChange={(e) => setMethod(e.target.value)}>{['UPI', 'Card', 'Net Banking', 'Wallet'].map((x) => <option key={x}>{x}</option>)}</select>
          <button className="btn" disabled={!picked.length || busy} onClick={confirm}>{busy ? 'Booking…' : 'Confirm booking'}</button></div>
        <p className="muted small">Payment is simulated for local testing.</p></>}
      <Msg text={err} />
    </main>
  );
}
