import React, { useState } from 'react';
import { Search, MapPin } from 'lucide-react';
import { useApi, qs } from '../api.jsx';
import { MovieCard, LocationPicker, useLoc } from '../components.jsx';

export default function Home() {
  const [loc, setLoc] = useLoc();
  const [f, setF] = useState({ q: '', languageId: '', genreId: '', status: 'running' });
  const [tq, setTq] = useState('');
  const [meta] = useApi('/meta');
  const [movies, err] = useApi('/movies?' + qs({ ...f, ...loc }));
  const [theatres] = useApi('/theatres?' + qs({ ...loc, q: tq }));
  return (
    <main>
      <section className="hero">
        <h1>Book Indian cinema, anywhere in India</h1>
        <p>Pick your state, district and city to see what's playing near you.</p>
        <div className="card pad"><b className="small"><MapPin size={14} /> Your location</b><LocationPicker value={loc} onChange={setLoc} /></div>
      </section>
      <section className="wrap">
        <div className="filters card pad">
          <div className="search"><Search size={16} /><input placeholder="Search movies by name" value={f.q} onChange={(e) => setF({ ...f, q: e.target.value })} /></div>
          <select value={f.languageId} onChange={(e) => setF({ ...f, languageId: e.target.value })}><option value="">All languages</option>{meta?.languages.map((l) => <option key={l.language_id} value={l.language_id}>{l.name}</option>)}</select>
          <select value={f.genreId} onChange={(e) => setF({ ...f, genreId: e.target.value })}><option value="">All genres</option>{meta?.genres.map((g) => <option key={g.genre_id} value={g.genre_id}>{g.name}</option>)}</select>
          <div className="seg">{[['running', 'Now showing'], ['upcoming', 'Upcoming'], ['', 'All']].map(([v, l]) => <button key={v} className={f.status === v ? 'on' : ''} onClick={() => setF({ ...f, status: v })}>{l}</button>)}</div>
        </div>
        {err && <div className="msg err">{err}</div>}
        {movies && !movies.length && <p className="muted center">No movies found for this selection yet. Admin can add movies and assign them to theatres.</p>}
        <div className="grid">{movies?.map((m) => <MovieCard key={m.movie_id} m={m} />)}</div>

        <h2 className="sec">Theatres {loc.cityId || loc.districtId || loc.stateId ? 'in your selected location' : 'across India'}</h2>
        <input className="wide" placeholder="Search theatres by name, city, district or state" value={tq} onChange={(e) => setTq(e.target.value)} />
        <div className="grid3">{theatres?.map((t) => (
          <div key={t.theatre_id} className="card pad"><b>{t.name}</b><div className="muted small">{t.address}</div>
            <div className="small">{t.city}, {t.district}, {t.state}</div><div className="tag">{t.screens} screens</div></div>))}
          {theatres && !theatres.length && <p className="muted">No theatres found.</p>}</div>
      </section>
    </main>
  );
}
