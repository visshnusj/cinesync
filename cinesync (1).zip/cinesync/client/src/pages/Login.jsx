import React, { useState } from 'react';
import { useNavigate, useLocation, Link } from 'react-router-dom';
import { api, useAuth } from '../api.jsx';
import { Msg } from '../components.jsx';

export function Login({ admin }) {
  const [f, setF] = useState({ email: '', password: '' }); const [err, setErr] = useState('');
  const { login } = useAuth(); const nav = useNavigate(); const loc = useLocation();
  const submit = async (e) => { e.preventDefault(); setErr('');
    try { const d = await api(admin ? '/auth/admin-login' : '/auth/login', { method: 'POST', body: f }); login(d); nav(admin ? '/admin' : loc.state?.from || '/'); }
    catch (x) { setErr(x.message); } };
  return (
    <div className="auth card"><h2>{admin ? 'Admin sign in' : 'Welcome back'}</h2>
      <form onSubmit={submit} className="stack">
        <input placeholder="Email" type="email" required value={f.email} onChange={(e) => setF({ ...f, email: e.target.value })} />
        <input placeholder="Password" type="password" required value={f.password} onChange={(e) => setF({ ...f, password: e.target.value })} />
        <Msg text={err} /><button className="btn">Sign in</button></form>
      {!admin && <p className="muted small">New here? <Link to="/register">Create an account</Link></p>}
    </div>
  );
}
export function Register() {
  const [f, setF] = useState({ name: '', email: '', phone: '', password: '' }); const [err, setErr] = useState('');
  const { login } = useAuth(); const nav = useNavigate();
  const submit = async (e) => { e.preventDefault(); setErr('');
    try { login(await api('/auth/register', { method: 'POST', body: f })); nav('/'); } catch (x) { setErr(x.message); } };
  return (
    <div className="auth card"><h2>Create account</h2>
      <form onSubmit={submit} className="stack">
        {['name', 'email', 'phone', 'password'].map((k) => <input key={k} required={k !== 'phone'} type={k === 'password' ? 'password' : 'text'} placeholder={k[0].toUpperCase() + k.slice(1) + (k === 'password' ? ' (min 6 chars)' : '')}
          value={f[k]} onChange={(e) => setF({ ...f, [k]: e.target.value })} />)}
        <Msg text={err} /><button className="btn">Sign up</button></form>
    </div>
  );
}
