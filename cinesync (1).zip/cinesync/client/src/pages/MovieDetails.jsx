import React, { useState, useEffect } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { Clock, Calendar as Cal, Ticket, BadgeCheck } from 'lucide-react';
import { api, useApi, useAuth, fmtDate } from '../api.jsx';
import { Stars, Msg } from '../components.jsx';

export default function MovieDetails() {
  const { id } = useParams(); const { auth } = useAuth();
  const [m, err, reload] = useApi('/movies/' + id, [id]);
  const [sort, setSort] = useState('recent');
  const [reviews, , reloadReviews] = useApi(`/movies/${id}/reviews?sort=${sort}`, [id, sort]);
  const [mine, , reloadMine] = useApi(auth?.role === 'user' ? `/movies/${id}/my-review` : null, [id, auth]);
  const [form, setForm] = useState({ rating: 0, title: '', text: '' }); const [msg, setMsg] = useState({});
  useEffect(() => { if (mine?.review) setForm({ rating: mine.review.rating, title: mine.review.review_title || '', text: mine.review.review_text || '' }); }, [mine]);
  const refresh = () => { reload(); reloadReviews(); reloadMine(); };
  const submit = async () => {
    try { await api(`/movies/${id}/reviews`, { method: mine?.review ? 'PUT' : 'POST', body: form }); setMsg({ ok: true, t: 'Review saved' }); refresh(); }
    catch (e) { setMsg({ t: e.message }); } };
  const remove = async () => { await api(`/movies/${id}/reviews`, { method: 'DELETE' }); setForm({ rating: 0, title: '', text: '' }); setMsg({ ok: true, t: 'Review deleted' }); refresh(); };
  if (err) return <div className="wrap"><Msg text={err} /></div>;
  if (!m) return <div className="wrap muted">Loading…</div>;
  const orig = m.languages.find((l) => l.type === 'original'); const dubbed = m.languages.filter((l) => l.type === 'dubbed');
  const total = m.review_count;
  return (
    <main className="wrap two-col">
      <section>
        <div className="detail-top">
          <img className="big-poster" src={m.poster_url} alt={m.title} />
          <div>
            <h1>{m.title}</h1>
            <div className="rate">{total ? <><Stars value={m.avg_rating} /> <b>{m.avg_rating}</b> <span className="muted">({total} reviews)</span></> : <span className="muted">No reviews yet</span>}</div>
            <div className="meta"><span><Clock size={14} /> {Math.floor(m.duration_min / 60)}h {m.duration_min % 60}m</span><span><Cal size={14} /> {fmtDate(m.release_date)}</span><span className="tag">{m.certification || 'NR'}</span></div>
            <div className="tags">{m.genres.map((g) => <span key={g.id} className="tag">{g.name}</span>)}</div>
            <p className="small"><b>Original language:</b> <span className="tag pri">{orig?.name}</span></p>
            {dubbed.length > 0 && <p className="small"><b>Dubbed:</b> {dubbed.map((l) => <span key={l.id} className="tag">{l.name}</span>)}</p>}
            <Link to={`/book/${m.movie_id}`} className="btn big"><Ticket size={16} /> Book Tickets</Link>
          </div>
        </div>
        <h3>About the movie</h3><p>{m.description}</p>
        <h3>Cast &amp; crew</h3><p style={{ whiteSpace: 'pre-line' }}>{m.cast_crew || '—'}</p>
        <h3>Available theatres</h3>
        <div className="grid3">{m.theatres.map((t) => <Link key={t.theatre_id} to={`/book/${m.movie_id}?theatre=${t.theatre_id}`} className="card pad"><b>{t.name}</b><div className="muted small">{t.city}, {t.district}, {t.state}</div></Link>)}
          {!m.theatres.length && <p className="muted">Not assigned to any theatre yet.</p>}</div>
      </section>

      <aside className="reviews card pad">
        <h3>Ratings &amp; reviews</h3>
        <div className="row"><div className="avg">{total ? m.avg_rating : '–'}</div><div><Stars value={m.avg_rating || 0} size={18} /><div className="muted small">{total} review{total === 1 ? '' : 's'}</div></div></div>
        {[5, 4, 3, 2, 1].map((s) => <div key={s} className="dist"><span>{s}★</span><div className="bar"><i style={{ width: total ? (m.distribution[s] / total) * 100 + '%' : 0 }} /></div><span className="muted small">{m.distribution[s]}</span></div>)}

        {auth?.role === 'user' ? (mine?.canReview || mine?.review ? (
          <div className="stack review-form"><b>{mine.review ? 'Edit your review' : 'Write a review'}</b>
            <Stars value={form.rating} size={24} onChange={(r) => setForm({ ...form, rating: r })} />
            <input placeholder="Review title" value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} />
            <textarea rows={3} placeholder="Share your thoughts" value={form.text} onChange={(e) => setForm({ ...form, text: e.target.value })} />
            <div className="row"><button className="btn" onClick={submit}>{mine.review ? 'Update' : 'Submit'}</button>{mine.review && <button className="btn ghost" onClick={remove}>Delete</button>}</div>
            <Msg text={msg.t} ok={msg.ok} /></div>
        ) : <p className="muted small">Book a ticket for this movie to leave a verified review.</p>)
          : <p className="muted small"><Link to="/login" state={{ from: '/movie/' + id }}>Log in</Link> to review after booking.</p>}

        <div className="row between"><b>Reviews</b><select value={sort} onChange={(e) => setSort(e.target.value)}><option value="recent">Most recent</option><option value="highest">Highest rated</option><option value="lowest">Lowest rated</option></select></div>
        {reviews?.map((r) => (
          <div key={r.review_id} className="review"><div className="row between"><b>{r.customer}</b><span className="muted small">{fmtDate(r.created_at)}</span></div>
            <Stars value={r.rating} size={14} /> {r.verified ? <span className="tag ok"><BadgeCheck size={12} /> Verified booking</span> : null}
            {r.review_title && <div><b>{r.review_title}</b></div>}<p className="small">{r.review_text}</p></div>))}
        {reviews && !reviews.length && <p className="muted small">No reviews yet.</p>}
      </aside>
    </main>
  );
}
