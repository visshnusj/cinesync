import React from 'react';
import { Routes, Route, NavLink, Navigate } from 'react-router-dom';
import { LayoutDashboard, Clapperboard, Building2, CalendarRange, Clock, Star, Users, Database, LogOut } from 'lucide-react';
import { useAuth } from '../../api.jsx';
import { Login } from '../Login.jsx';
import Dashboard from './Dashboard.jsx';
import { Movies, Theatres } from './MoviesTheatres.jsx';
import { Seasons, Shows } from './SeasonsShows.jsx';
import { Reviews, Customers, MasterData } from './Others.jsx';

const links = [['', 'Dashboard', LayoutDashboard], ['movies', 'Movies', Clapperboard], ['theatres', 'Theatres & Screens', Building2], ['seasons', 'Seasonal Timings', CalendarRange],
  ['shows', 'Shows', Clock], ['reviews', 'Reviews', Star], ['customers', 'Customers', Users], ['master', 'Locations & Master Data', Database]];

export default function AdminLayout() {
  const { auth, logout } = useAuth();
  if (auth?.role !== 'admin') return <Routes><Route path="*" element={<div className="admin-login"><Login admin /></div>} /></Routes>;
  return (
    <div className="admin">
      <aside className="side">
        <div className="brand">CineSync <small>Admin</small></div>
        {links.map(([to, label, Icon]) => <NavLink key={to} end={to === ''} to={'/admin/' + to} className="sl"><Icon size={17} /> {label}</NavLink>)}
        <button className="sl" onClick={logout}><LogOut size={17} /> Logout</button>
        <NavLink to="/" className="sl muted">← Customer site</NavLink>
      </aside>
      <section className="content">
        <Routes>
          <Route index element={<Dashboard />} /><Route path="movies" element={<Movies />} /><Route path="theatres" element={<Theatres />} />
          <Route path="seasons" element={<Seasons />} /><Route path="shows" element={<Shows />} /><Route path="reviews" element={<Reviews />} />
          <Route path="customers" element={<Customers />} /><Route path="master" element={<MasterData />} /><Route path="*" element={<Navigate to="/admin" />} />
        </Routes>
      </section>
    </div>
  );
}
