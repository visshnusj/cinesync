import React, { useState } from 'react';
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, CartesianGrid, LineChart, Line, Legend } from 'recharts';
import { Users, Ticket, XCircle, Armchair, IndianRupee, Percent } from 'lucide-react';
import { useApi, qs, money, fmtTime, fmtDate } from '../../api.jsx';
import { LocationPicker } from '../../components.jsx';

const Card = ({ icon: I, label, value }) => <div className="card stat"><I size={20} /><div><div className="muted small">{label}</div><b>{value}</b></div></div>;
const Chart = ({ title, data }) => (
  <div className="card pad"><b>{title}</b><div style={{ height: 240 }}><ResponsiveContainer>
    <BarChart data={data || []} layout="vertical" margin={{ left: 20 }}><CartesianGrid strokeDasharray="3 3" /><XAxis type="number" allowDecimals={false} /><YAxis type="category" dataKey="label" width={110} tick={{ fontSize: 11 }} />
      <Tooltip /><Bar dataKey="tickets" name="Tickets" fill="#e11d48" radius={3} /><Bar dataKey="customers" name="Customers" fill="#6366f1" radius={3} /></BarChart></ResponsiveContainer></div></div>
);

export default function Dashboard() {
  const [loc, setLoc] = useState({}); const [f, setF] = useState({ theatreId: '', movieId: '', date: '', showTime: '' }); const [period, setPeriod] = useState('daily');
  const [theatres] = useApi('/admin/theatres'); const [movies] = useApi('/admin/movies');
  const [s, err] = useApi('/admin/stats?' + qs({ ...loc, ...f }));
  const c = s?.cards;
  return (
    <>
      <h2>Booking &amp; customer monitoring</h2>
      <div className="card pad stack"><LocationPicker value={loc} onChange={(v) => { setLoc(v); setF({ ...f, theatreId: '' }); }} compact />
        <div className="row wrap">
          <select value={f.theatreId} onChange={(e) => setF({ ...f, theatreId: e.target.value })}><option value="">All theatres</option>
            {theatres?.filter((t) => (!loc.stateId || t.state_id == loc.stateId) && (!loc.districtId || t.district_id == loc.districtId) && (!loc.cityId || t.city_id == loc.cityId)).map((t) => <option key={t.theatre_id} value={t.theatre_id}>{t.name}</option>)}</select>
          <select value={f.movieId} onChange={(e) => setF({ ...f, movieId: e.target.value })}><option value="">All movies</option>{movies?.map((m) => <option key={m.movie_id} value={m.movie_id}>{m.title}</option>)}</select>
          <input type="date" value={f.date} onChange={(e) => setF({ ...f, date: e.target.value })} /><input type="time" value={f.showTime} onChange={(e) => setF({ ...f, showTime: e.target.value })} title="Show time" />
          <button className="btn ghost" onClick={() => { setLoc({}); setF({ theatreId: '', movieId: '', date: '', showTime: '' }); }}>Reset</button></div></div>
      {err && <div className="msg err">{err}</div>}
      {c && <div className="stats">
        <Card icon={Users} label="Registered customers" value={c.customers} /><Card icon={Ticket} label="Tickets booked" value={c.tickets} />
        <Card icon={XCircle} label="Cancelled bookings" value={c.cancelled} /><Card icon={Armchair} label="Occupied / Available" value={`${c.occupied} / ${c.available}`} />
        <Card icon={Percent} label="Overall occupancy" value={c.capacity ? Math.round((c.occupied / c.capacity) * 100) + '%' : '0%'} /><Card icon={IndianRupee} label="Revenue" value={money(c.revenue)} /></div>}
      {s && <div className="card pad"><div className="row between"><b>Bookings over time</b><div className="seg">{['daily', 'weekly', 'monthly'].map((p) => <button key={p} className={period === p ? 'on' : ''} onClick={() => setPeriod(p)}>{p}</button>)}</div></div>
        <div style={{ height: 260 }}><ResponsiveContainer><LineChart data={s[period]}><CartesianGrid strokeDasharray="3 3" /><XAxis dataKey="label" tick={{ fontSize: 11 }} /><YAxis allowDecimals={false} /><Tooltip /><Legend />
          <Line type="monotone" dataKey="tickets" name="Tickets" stroke="#e11d48" strokeWidth={2} /><Line type="monotone" dataKey="customers" name="Customers" stroke="#6366f1" strokeWidth={2} /></LineChart></ResponsiveContainer></div></div>}
      {s && <div className="grid2">
        <Chart title="State-wise bookings" data={s.byState} /><Chart title="District-wise bookings" data={s.byDistrict} /><Chart title="Theatre-wise customers" data={s.byTheatre} />
        <Chart title="Movie-wise bookings" data={s.byMovie} /><Chart title="Language-wise bookings" data={s.byLanguage} /><Chart title="Genre-wise bookings" data={s.byGenre} /></div>}
      {s && <div className="card pad"><b>Show-wise occupancy</b><div className="tablewrap"><table><thead><tr><th>Movie</th><th>Theatre / Screen</th><th>Date</th><th>Time</th><th>Customers</th><th>Booked</th><th>Available</th><th>Occupancy</th></tr></thead>
        <tbody>{s.shows.map((r) => <tr key={r.show_id}><td>{r.title}</td><td>{r.theatre} / {r.screen_no}</td><td>{fmtDate(r.start_at)}</td><td>{fmtTime(r.start_at)}</td><td>{r.customers}</td><td>{r.booked}</td><td>{r.available}</td>
          <td><div className="bar"><i style={{ width: r.occupancy + '%' }} /></div> {r.occupancy}%</td></tr>)}</tbody></table>{!s.shows.length && <p className="muted">No shows match.</p>}</div></div>}
    </>
  );
}
