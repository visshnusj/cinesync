import React, { useState } from 'react';
import { Pencil, Trash2, Plus } from 'lucide-react';
import { api, useApi } from '../../api.jsx';
import { LocationPicker, Msg, Stars } from '../../components.jsx';

const empty = { title: '', description: '', durationMin: 140, releaseDate: '', availableFrom: '', availableTo: '', certification: 'U/A', castCrew: '', originalLanguageId: '', dubbedLanguageIds: [], genreIds: [], theatreIds: [] };
const Checks = ({ items, idKey, label, value, onChange }) => (
  <div className="checks">{items?.map((i) => <label key={i[idKey]} className={'chk ' + (value.includes(i[idKey]) ? 'on' : '')}>
    <input type="checkbox" checked={value.includes(i[idKey])} onChange={() => onChange(value.includes(i[idKey]) ? value.filter((x) => x !== i[idKey]) : [...value, i[idKey]])} />{i[label]}</label>)}</div>
);

export function Movies() {
  const [movies, , reload] = useApi('/admin/movies'); const [meta] = useApi('/meta'); const [theatres] = useApi('/admin/theatres');
  const [f, setF] = useState(empty); const [editing, setEditing] = useState(null); const [file, setFile] = useState(null); const [msg, setMsg] = useState({});
  const set = (k, v) => setF({ ...f, [k]: v });
  const edit = (m) => { setEditing(m.movie_id); setFile(null); window.scrollTo(0, 0);
    setF({ title: m.title, description: m.description || '', durationMin: m.duration_min, releaseDate: m.release_date, availableFrom: m.available_from || '', availableTo: m.available_to || '', certification: m.certification || '', castCrew: m.cast_crew || '',
      originalLanguageId: m.languages.find((l) => l.type === 'original')?.id || '', dubbedLanguageIds: m.languages.filter((l) => l.type === 'dubbed').map((l) => l.id), genreIds: m.genres.map((g) => g.id), theatreIds: m.theatre_ids }); };
  const submit = async (e) => { e.preventDefault(); setMsg({});
    const fd = new FormData(); Object.entries(f).forEach(([k, v]) => fd.append(k, Array.isArray(v) ? JSON.stringify(v) : v)); if (file) fd.append('poster', file);
    try { await api('/admin/movies' + (editing ? '/' + editing : ''), { method: editing ? 'PUT' : 'POST', form: fd }); setMsg({ ok: true, t: editing ? 'Movie updated' : 'Movie added' }); setF(empty); setEditing(null); setFile(null); e.target.reset(); reload(); }
    catch (x) { setMsg({ t: x.message }); } };
  const del = async (id) => { if (!confirm('Delete this movie?')) return; try { await api('/admin/movies/' + id, { method: 'DELETE' }); reload(); } catch (x) { setMsg({ t: x.message }); } };
  return (
    <>
      <h2>Movies</h2>
      <form className="card pad stack" onSubmit={submit}><b>{editing ? 'Edit movie' : 'Add movie'}</b>
        <div className="grid2">
          <input required placeholder="Title" value={f.title} onChange={(e) => set('title', e.target.value)} />
          <input required type="number" placeholder="Duration (minutes)" value={f.durationMin} onChange={(e) => set('durationMin', e.target.value)} />
          <label className="small">Release date<input required type="date" value={f.releaseDate} onChange={(e) => set('releaseDate', e.target.value)} /></label>
          <select value={f.certification} onChange={(e) => set('certification', e.target.value)}>{['U', 'U/A', 'A', 'S'].map((c) => <option key={c}>{c}</option>)}</select>
          <label className="small">Available from<input type="date" value={f.availableFrom} onChange={(e) => set('availableFrom', e.target.value)} /></label>
          <label className="small">Available to<input type="date" value={f.availableTo} onChange={(e) => set('availableTo', e.target.value)} /></label></div>
        <textarea rows={3} placeholder="Description" value={f.description} onChange={(e) => set('description', e.target.value)} />
        <textarea rows={3} placeholder="Cast and crew (one per line, e.g. Director: …)" value={f.castCrew} onChange={(e) => set('castCrew', e.target.value)} />
        <label className="small">Original language<select required value={f.originalLanguageId} onChange={(e) => set('originalLanguageId', e.target.value)}><option value="">Select</option>{meta?.languages.map((l) => <option key={l.language_id} value={l.language_id}>{l.name}</option>)}</select></label>
        <div><span className="small">Dubbed versions</span><Checks items={meta?.languages.filter((l) => String(l.language_id) !== String(f.originalLanguageId))} idKey="language_id" label="name" value={f.dubbedLanguageIds} onChange={(v) => set('dubbedLanguageIds', v)} /></div>
        <div><span className="small">Genres (multiple)</span><Checks items={meta?.genres} idKey="genre_id" label="name" value={f.genreIds} onChange={(v) => set('genreIds', v)} /></div>
        <div><span className="small">Assign to theatres</span><Checks items={theatres?.map((t) => ({ ...t, label: `${t.name} (${t.city})` }))} idKey="theatre_id" label="label" value={f.theatreIds} onChange={(v) => set('theatreIds', v)} /></div>
        <label className="small">Poster {editing ? '(leave empty to keep current)' : '(required)'}<input type="file" accept="image/*" required={!editing} onChange={(e) => setFile(e.target.files[0])} /></label>
        <Msg text={msg.t} ok={msg.ok} /><div className="row"><button className="btn"><Plus size={15} /> {editing ? 'Save changes' : 'Add movie'}</button>{editing && <button type="button" className="btn ghost" onClick={() => { setEditing(null); setF(empty); }}>Cancel</button>}</div>
      </form>
      <div className="card pad tablewrap"><table><thead><tr><th>Poster</th><th>Title</th><th>Languages</th><th>Genres</th><th>Rating</th><th>Release</th><th /></tr></thead>
        <tbody>{movies?.map((m) => <tr key={m.movie_id}><td><img src={m.poster_url} className="mini" alt="" /></td><td><b>{m.title}</b><div className="muted small">{m.duration_min} min • {m.certification}</div></td>
          <td>{m.languages.map((l) => l.name + (l.type === 'dubbed' ? ' (dub)' : '')).join(', ')}</td><td>{m.genres.map((g) => g.name).join(', ')}</td>
          <td>{m.review_count ? <><Stars value={m.avg_rating} size={12} /> {m.avg_rating} ({m.review_count})</> : '—'}</td><td>{m.release_date}</td>
          <td className="row"><button className="icon" onClick={() => edit(m)}><Pencil size={15} /></button><button className="icon" onClick={() => del(m.movie_id)}><Trash2 size={15} /></button></td></tr>)}</tbody></table></div>
    </>
  );
}

export function Theatres() {
  const [list, , reload] = useApi('/admin/theatres'); const [f, setF] = useState({ name: '', address: '' }); const [loc, setLoc] = useState({}); const [editing, setEditing] = useState(null);
  const [sf, setSf] = useState({ screenNo: 1, name: '', totalRows: 8, seatsPerRow: 12, price: 150 }); const [target, setTarget] = useState(null); const [msg, setMsg] = useState({});
  const run = async (fn, ok) => { setMsg({}); try { await fn(); setMsg({ ok: true, t: ok }); reload(); } catch (e) { setMsg({ t: e.message }); } };
  const save = (e) => { e.preventDefault(); run(async () => { await api('/admin/theatres' + (editing ? '/' + editing : ''), { method: editing ? 'PUT' : 'POST', body: { ...f, cityId: loc.cityId } }); setF({ name: '', address: '' }); setLoc({}); setEditing(null); }, 'Theatre saved'); };
  return (
    <>
      <h2>Theatres &amp; screens</h2><Msg text={msg.t} ok={msg.ok} />
      <form className="card pad stack" onSubmit={save}><b>{editing ? 'Edit theatre' : 'Add theatre'}</b>
        <div className="grid2"><input required placeholder="Theatre name" value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} /><input placeholder="Address" value={f.address} onChange={(e) => setF({ ...f, address: e.target.value })} /></div>
        <LocationPicker value={loc} onChange={setLoc} /><div className="row"><button className="btn" disabled={!loc.cityId}>{editing ? 'Update' : 'Add theatre'}</button>{!loc.cityId && <span className="muted small">Select state, district and city</span>}</div></form>
      {list?.map((t) => (
        <div key={t.theatre_id} className="card pad">
          <div className="row between"><div><b>{t.name}</b><div className="muted small">{t.address} • {t.city}, {t.district}, {t.state}</div></div>
            <div className="row"><button className="icon" onClick={() => { setEditing(t.theatre_id); setF({ name: t.name, address: t.address }); setLoc({ stateId: t.state_id, districtId: t.district_id, cityId: t.city_id }); window.scrollTo(0, 0); }}><Pencil size={15} /></button>
              <button className="icon" onClick={() => confirm('Delete theatre?') && run(() => api('/admin/theatres/' + t.theatre_id, { method: 'DELETE' }), 'Deleted')}><Trash2 size={15} /></button></div></div>
          <table><thead><tr><th>Screen</th><th>Name</th><th>Layout</th><th>Capacity</th><th>Ticket price ₹</th><th /></tr></thead><tbody>
            {t.screens.map((s) => <tr key={s.screen_id}><td>{s.screen_no}</td><td>{s.name}</td><td>{s.total_rows} rows × {s.seats_per_row}</td><td>{s.total_rows * s.seats_per_row}</td>
              <td><input type="number" defaultValue={s.price} style={{ width: 90 }} onBlur={(e) => e.target.value != s.price && run(() => api('/admin/screens/' + s.screen_id, { method: 'PUT', body: { price: e.target.value } }), 'Price updated (also applied to upcoming shows)')} /></td>
              <td><button className="icon" onClick={() => confirm('Delete screen?') && run(() => api('/admin/screens/' + s.screen_id, { method: 'DELETE' }), 'Screen deleted')}><Trash2 size={15} /></button></td></tr>)}</tbody></table>
          {target === t.theatre_id ? <form className="row wrap" onSubmit={(e) => { e.preventDefault(); run(() => api(`/admin/theatres/${t.theatre_id}/screens`, { method: 'POST', body: sf }), 'Screen added'); }}>
            {[['screenNo', 'Screen no'], ['name', 'Name'], ['totalRows', 'Rows'], ['seatsPerRow', 'Seats/row'], ['price', 'Price ₹']].map(([k, p]) => <input key={k} style={{ width: 110 }} placeholder={p} title={p} value={sf[k]} onChange={(e) => setSf({ ...sf, [k]: e.target.value })} />)}
            <button className="btn">Add screen</button></form>
            : <button className="btn ghost" onClick={() => { setTarget(t.theatre_id); setSf({ ...sf, screenNo: t.screens.length + 1 }); }}><Plus size={14} /> Add screen</button>}
        </div>))}
    </>
  );
}
