import React, { useState } from 'react';
import { api, useApi, qs, fmtDate } from '../../api.jsx';
import { Stars, Msg, LocationPicker } from '../../components.jsx';

export function Reviews() {
  const [movies] = useApi('/admin/movies'); const [flt, setFlt] = useState({ movieId: '', status: '' }); const [rows, , reload] = useApi('/admin/reviews?' + qs(flt));
  const set = async (id, status) => { await api(`/admin/reviews/${id}/status`, { method: 'PUT', body: { status } }); reload(); };
  return (
    <>
      <h2>Review monitoring</h2>
      <div className="stats">{movies?.filter((m) => m.review_count).map((m) => <div key={m.movie_id} className="card pad"><b>{m.title}</b><div><Stars value={m.avg_rating} size={13} /> {m.avg_rating} <span className="muted small">({m.review_count})</span></div></div>)}</div>
      <div className="card pad row wrap"><select value={flt.movieId} onChange={(e) => setFlt({ ...flt, movieId: e.target.value })}><option value="">All movies</option>{movies?.map((m) => <option key={m.movie_id} value={m.movie_id}>{m.title}</option>)}</select>
        <select value={flt.status} onChange={(e) => setFlt({ ...flt, status: e.target.value })}><option value="">All</option><option value="visible">Visible</option><option value="hidden">Hidden</option></select></div>
      {rows?.map((r) => <div key={r.review_id} className={'card pad ' + (r.review_status === 'hidden' ? 'off' : '')}><div className="row between"><div><b>{r.title}</b> — {r.customer} <span className="muted small">{fmtDate(r.created_at)}</span></div>
        {r.review_status === 'visible' ? <button className="btn danger" onClick={() => set(r.review_id, 'hidden')}>Hide</button> : <button className="btn ghost" onClick={() => set(r.review_id, 'visible')}>Restore</button>}</div>
        <Stars value={r.rating} size={14} /> <span className={'tag ' + (r.rating >= 4 ? 'ok' : r.rating <= 2 ? 'bad' : '')}>{r.rating >= 4 ? 'Positive' : r.rating <= 2 ? 'Negative' : 'Neutral'}</span>{r.verified ? <span className="tag ok">Verified</span> : null}
        <div><b>{r.review_title}</b></div><p className="small">{r.review_text}</p></div>)}
      {rows && !rows.length && <p className="muted">No reviews.</p>}
    </>
  );
}

export function Customers() {
  const [rows] = useApi('/admin/customers');
  return (<><h2>Customers ({rows?.length ?? 0})</h2><div className="card pad tablewrap"><table><thead><tr><th>Name</th><th>Email</th><th>Phone</th><th>Joined</th><th>Bookings</th><th>Tickets</th><th>Cancelled</th></tr></thead>
    <tbody>{rows?.map((c) => <tr key={c.user_id}><td>{c.name}</td><td>{c.email}</td><td>{c.phone}</td><td>{c.created_at.slice(0, 10)}</td><td>{c.bookings}</td><td>{c.tickets}</td><td>{c.cancelled}</td></tr>)}</tbody></table></div></>);
}

export function MasterData() {
  const [meta, , reloadMeta] = useApi('/meta'); const [states] = useApi('/locations/states'); const [msg, setMsg] = useState({});
  const [d, setD] = useState({ stateId: '', name: '' }); const [c, setC] = useState({ loc: {}, name: '' }); const [lang, setLang] = useState(''); const [genre, setGenre] = useState('');
  const run = (fn, ok) => async (e) => { e.preventDefault(); setMsg({}); try { await fn(); setMsg({ ok: true, t: ok }); reloadMeta(); } catch (x) { setMsg({ t: x.message }); } };
  return (
    <>
      <h2>Locations &amp; master data</h2><Msg text={msg.t} ok={msg.ok} />
      <p className="muted small">All Indian states and Union Territories are preloaded with starter districts and cities. Add any additional district, city, language or genre below.</p>
      <form className="card pad row wrap" onSubmit={run(() => api('/admin/districts', { method: 'POST', body: d }), 'District added')}><b>Add district</b>
        <select required value={d.stateId} onChange={(e) => setD({ ...d, stateId: e.target.value })}><option value="">State / UT</option>{states?.map((s) => <option key={s.state_id} value={s.state_id}>{s.name}</option>)}</select>
        <input required placeholder="District name" value={d.name} onChange={(e) => setD({ ...d, name: e.target.value })} /><button className="btn">Add</button></form>
      <form className="card pad stack" onSubmit={run(() => api('/admin/cities', { method: 'POST', body: { districtId: c.loc.districtId, name: c.name } }), 'City added')}><b>Add city</b>
        <LocationPicker value={c.loc} onChange={(loc) => setC({ ...c, loc })} /><div className="row"><input required placeholder="City name" value={c.name} onChange={(e) => setC({ ...c, name: e.target.value })} /><button className="btn" disabled={!c.loc.districtId}>Add</button></div></form>
      <div className="grid2">
        <form className="card pad stack" onSubmit={run(() => api('/admin/languages', { method: 'POST', body: { name: lang } }), 'Language added')}><b>Languages ({meta?.languages.length})</b>
          <div className="tags">{meta?.languages.map((l) => <span key={l.language_id} className="tag">{l.name}</span>)}</div><div className="row"><input required placeholder="New Indian language" value={lang} onChange={(e) => setLang(e.target.value)} /><button className="btn">Add</button></div></form>
        <form className="card pad stack" onSubmit={run(() => api('/admin/genres', { method: 'POST', body: { name: genre } }), 'Genre added')}><b>Genres ({meta?.genres.length})</b>
          <div className="tags">{meta?.genres.map((l) => <span key={l.genre_id} className="tag">{l.name}</span>)}</div><div className="row"><input required placeholder="New genre" value={genre} onChange={(e) => setGenre(e.target.value)} /><button className="btn">Add</button></div></form></div>
    </>
  );
}
