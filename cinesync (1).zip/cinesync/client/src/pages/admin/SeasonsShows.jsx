import React, { useState } from 'react';
import { Trash2, Wand2, Pencil } from 'lucide-react';
import { api, useApi, qs, money, fmtTime, fmtDate } from '../../api.jsx';
import { Msg } from '../../components.jsx';

const t5 = (t) => t.slice(0, 5);
export function Seasons() {
  const [seasons, , reload] = useApi('/admin/seasons'); const [theatres] = useApi('/admin/theatres');
  const [f, setF] = useState({ name: '', startDate: '', endDate: '' }); const [editing, setEditing] = useState(null); const [msg, setMsg] = useState({});
  const [as, setAs] = useState({ seasonId: '', theatreIds: [], openTime: '09:00', closeTime: '23:59' });
  const run = async (fn, ok) => { setMsg({}); try { await fn(); setMsg({ ok: true, t: ok }); reload(); } catch (e) { setMsg({ t: e.message }); } };
  return (
    <>
      <h2>Seasonal theatre timings</h2><Msg text={msg.t} ok={msg.ok} />
      <form className="card pad row wrap" onSubmit={(e) => { e.preventDefault(); run(async () => { await api('/admin/seasons' + (editing ? '/' + editing : ''), { method: editing ? 'PUT' : 'POST', body: f }); setF({ name: '', startDate: '', endDate: '' }); setEditing(null); }, 'Season saved'); }}>
        <input required placeholder="Season name (Summer, Winter, Festival…)" value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} />
        <label className="small">Start<input required type="date" value={f.startDate} onChange={(e) => setF({ ...f, startDate: e.target.value })} /></label>
        <label className="small">End<input required type="date" value={f.endDate} onChange={(e) => setF({ ...f, endDate: e.target.value })} /></label>
        <button className="btn">{editing ? 'Update season' : 'Create season'}</button></form>

      <form className="card pad stack" onSubmit={(e) => { e.preventDefault(); run(() => api('/admin/schedules', { method: 'POST', body: as }), 'Schedule assigned'); }}>
        <b>Assign opening &amp; closing hours to theatres</b>
        <div className="row wrap"><select required value={as.seasonId} onChange={(e) => setAs({ ...as, seasonId: e.target.value })}><option value="">Select season</option>{seasons?.map((s) => <option key={s.season_id} value={s.season_id}>{s.name} ({s.start_date} → {s.end_date})</option>)}</select>
          <label className="small">Opens<input type="time" value={as.openTime} onChange={(e) => setAs({ ...as, openTime: e.target.value })} /></label>
          <label className="small">Closes<input type="time" value={as.closeTime} onChange={(e) => setAs({ ...as, closeTime: e.target.value })} /></label></div>
        <div className="checks">{theatres?.map((t) => <label key={t.theatre_id} className={'chk ' + (as.theatreIds.includes(t.theatre_id) ? 'on' : '')}><input type="checkbox" checked={as.theatreIds.includes(t.theatre_id)}
          onChange={() => setAs({ ...as, theatreIds: as.theatreIds.includes(t.theatre_id) ? as.theatreIds.filter((x) => x !== t.theatre_id) : [...as.theatreIds, t.theatre_id] })} />{t.name} ({t.city})</label>)}</div>
        <div className="muted small">A closing time earlier than the opening time means the theatre closes after midnight (e.g. 09:00 → 00:00). Overlapping seasons for one theatre are rejected.</div>
        <button className="btn">Assign schedule</button></form>

      {seasons?.map((s) => (
        <div key={s.season_id} className="card pad"><div className="row between"><div><b>{s.name}</b> <span className="tag pri">{s.start_date} → {s.end_date}</span></div>
          <div className="row"><button className="icon" onClick={() => { setEditing(s.season_id); setF({ name: s.name, startDate: s.start_date, endDate: s.end_date }); window.scrollTo(0, 0); }}><Pencil size={15} /></button>
            <button className="icon" onClick={() => confirm('Delete season and its schedules?') && run(() => api('/admin/seasons/' + s.season_id, { method: 'DELETE' }), 'Season deleted')}><Trash2 size={15} /></button></div></div>
          {s.schedules.map((x) => <div key={x.schedule_id} className="row between small"><span>{x.theatre} ({x.city})</span><span>{t5(x.open_time)} – {t5(x.close_time)}
            <button className="icon" onClick={() => run(() => api('/admin/schedules/' + x.schedule_id, { method: 'DELETE' }), 'Schedule removed')}><Trash2 size={13} /></button></span></div>)}
          {!s.schedules.length && <div className="muted small">No theatres assigned.</div>}</div>))}
    </>
  );
}

export function Shows() {
  const [movies] = useApi('/admin/movies'); const [theatres] = useApi('/admin/theatres');
  const [g, setG] = useState({ movieId: '', theatreId: '', screenId: '', fromDate: '', toDate: '' });
  const [flt, setFlt] = useState({ date: '', movieId: '', theatreId: '' }); const [shows, , reload] = useApi('/admin/shows?' + qs(flt)); const [msg, setMsg] = useState({});
  const run = async (fn, ok) => { setMsg({}); try { const r = await fn(); setMsg({ ok: true, t: ok || r?.t }); reload(); } catch (e) { setMsg({ t: e.message }); } };
  const screens = theatres?.find((t) => t.theatre_id == g.theatreId)?.screens || [];
  const generate = (e) => { e.preventDefault(); run(async () => { const r = await api('/admin/shows/generate', { method: 'POST', body: g }); return { t: `${r.created} shows created. ${r.notes.join(' • ')}` }; }); };
  return (
    <>
      <h2>Show management</h2><Msg text={msg.t} ok={msg.ok} />
      <form className="card pad stack" onSubmit={generate}><b><Wand2 size={15} /> Auto-generate up to 5 shows per day</b>
        <div className="row wrap"><select required value={g.movieId} onChange={(e) => setG({ ...g, movieId: e.target.value })}><option value="">Movie</option>{movies?.map((m) => <option key={m.movie_id} value={m.movie_id}>{m.title} ({m.duration_min}m)</option>)}</select>
          <select required value={g.theatreId} onChange={(e) => setG({ ...g, theatreId: e.target.value, screenId: '' })}><option value="">Theatre</option>{theatres?.map((t) => <option key={t.theatre_id} value={t.theatre_id}>{t.name} ({t.city})</option>)}</select>
          <select value={g.screenId} onChange={(e) => setG({ ...g, screenId: e.target.value })}><option value="">All screens</option>{screens.map((s) => <option key={s.screen_id} value={s.screen_id}>Screen {s.screen_no}</option>)}</select>
          <input required type="date" value={g.fromDate} onChange={(e) => setG({ ...g, fromDate: e.target.value })} /><input required type="date" value={g.toDate} onChange={(e) => setG({ ...g, toDate: e.target.value })} />
          <button className="btn">Generate</button></div>
        <div className="muted small">Timings follow the theatre's active seasonal hours, movie duration and a 20-minute cleaning gap. Overlapping slots on a screen are skipped — use different screens for different movies.</div></form>

      <div className="card pad row wrap"><b>View schedule</b><input type="date" value={flt.date} onChange={(e) => setFlt({ ...flt, date: e.target.value })} />
        <select value={flt.movieId} onChange={(e) => setFlt({ ...flt, movieId: e.target.value })}><option value="">All movies</option>{movies?.map((m) => <option key={m.movie_id} value={m.movie_id}>{m.title}</option>)}</select>
        <select value={flt.theatreId} onChange={(e) => setFlt({ ...flt, theatreId: e.target.value })}><option value="">All theatres</option>{theatres?.map((t) => <option key={t.theatre_id} value={t.theatre_id}>{t.name}</option>)}</select></div>
      <div className="card pad tablewrap"><table><thead><tr><th>Date</th><th>Movie</th><th>Theatre / Screen</th><th>Start</th><th>End</th><th>Price</th><th>Booked</th><th>Active</th><th /></tr></thead><tbody>
        {shows?.map((s) => <tr key={s.show_id} className={s.is_active ? '' : 'off'}><td>{s.show_date}</td><td>{s.title}</td><td>{s.theatre} / {s.screen_no}</td>
          <td><input type="time" defaultValue={s.start_at.slice(11, 16)} onBlur={(e) => e.target.value !== s.start_at.slice(11, 16) && run(() => api('/admin/shows/' + s.show_id, { method: 'PUT', body: { startTime: e.target.value, nextDay: s.start_at.slice(0, 10) > s.show_date && e.target.value < '12:00' } }), 'Timing updated')} /></td>
          <td>{s.end_at.slice(11, 16)}</td><td>{money(s.price)}</td><td>{s.booked}/{s.capacity}</td>
          <td><input type="checkbox" checked={!!s.is_active} onChange={(e) => run(() => api('/admin/shows/' + s.show_id, { method: 'PUT', body: { isActive: e.target.checked } }), 'Show updated')} /></td>
          <td><button className="icon" onClick={() => confirm('Delete show?') && run(() => api('/admin/shows/' + s.show_id, { method: 'DELETE' }), 'Show deleted')}><Trash2 size={15} /></button></td></tr>)}</tbody></table>
        {shows && !shows.length && <p className="muted">No shows found.</p>}</div>
    </>
  );
}
