CREATE DATABASE IF NOT EXISTS cinesync CHARACTER SET utf8mb4;
USE cinesync;

CREATE TABLE IF NOT EXISTS users (
  user_id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  email VARCHAR(150) NOT NULL UNIQUE,
  phone VARCHAR(20),
  password_hash VARCHAR(255) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS admins (
  admin_id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  email VARCHAR(150) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS countries (
  country_id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(80) NOT NULL UNIQUE
);
CREATE TABLE IF NOT EXISTS states (
  state_id INT AUTO_INCREMENT PRIMARY KEY,
  country_id INT NOT NULL,
  name VARCHAR(100) NOT NULL UNIQUE,
  type ENUM('State','Union Territory') NOT NULL DEFAULT 'State',
  FOREIGN KEY (country_id) REFERENCES countries(country_id)
);
CREATE TABLE IF NOT EXISTS districts (
  district_id INT AUTO_INCREMENT PRIMARY KEY,
  state_id INT NOT NULL,
  name VARCHAR(100) NOT NULL,
  UNIQUE KEY uq_district (state_id, name),
  FOREIGN KEY (state_id) REFERENCES states(state_id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS cities (
  city_id INT AUTO_INCREMENT PRIMARY KEY,
  district_id INT NOT NULL,
  name VARCHAR(100) NOT NULL,
  UNIQUE KEY uq_city (district_id, name),
  FOREIGN KEY (district_id) REFERENCES districts(district_id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS theatres (
  theatre_id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(150) NOT NULL,
  address VARCHAR(255),
  city_id INT NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_theatre_city (city_id),
  FOREIGN KEY (city_id) REFERENCES cities(city_id)
);
CREATE TABLE IF NOT EXISTS screens (
  screen_id INT AUTO_INCREMENT PRIMARY KEY,
  theatre_id INT NOT NULL,
  screen_no INT NOT NULL,
  name VARCHAR(60),
  total_rows INT NOT NULL,
  seats_per_row INT NOT NULL,
  price DECIMAL(8,2) NOT NULL DEFAULT 150,
  UNIQUE KEY uq_screen (theatre_id, screen_no),
  FOREIGN KEY (theatre_id) REFERENCES theatres(theatre_id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS seats (
  seat_id INT AUTO_INCREMENT PRIMARY KEY,
  screen_id INT NOT NULL,
  row_label CHAR(2) NOT NULL,
  seat_number INT NOT NULL,
  UNIQUE KEY uq_seat (screen_id, row_label, seat_number),
  FOREIGN KEY (screen_id) REFERENCES screens(screen_id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS seasons (
  season_id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(80) NOT NULL,
  start_date DATE NOT NULL,
  end_date DATE NOT NULL
);
CREATE TABLE IF NOT EXISTS seasonal_schedules (
  schedule_id INT AUTO_INCREMENT PRIMARY KEY,
  season_id INT NOT NULL,
  theatre_id INT NOT NULL,
  open_time TIME NOT NULL,
  close_time TIME NOT NULL,
  UNIQUE KEY uq_sched (season_id, theatre_id),
  FOREIGN KEY (season_id) REFERENCES seasons(season_id) ON DELETE CASCADE,
  FOREIGN KEY (theatre_id) REFERENCES theatres(theatre_id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS languages (
  language_id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(60) NOT NULL UNIQUE
);
CREATE TABLE IF NOT EXISTS genres (
  genre_id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(60) NOT NULL UNIQUE
);
CREATE TABLE IF NOT EXISTS movies (
  movie_id INT AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(200) NOT NULL,
  description TEXT,
  duration_min INT NOT NULL,
  release_date DATE NOT NULL,
  available_from DATE,
  available_to DATE,
  certification VARCHAR(10),
  cast_crew TEXT,
  poster_url VARCHAR(255) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_movie_release (release_date)
);
CREATE TABLE IF NOT EXISTS movie_languages (
  movie_id INT NOT NULL,
  language_id INT NOT NULL,
  version_type ENUM('original','dubbed') NOT NULL,
  PRIMARY KEY (movie_id, language_id),
  FOREIGN KEY (movie_id) REFERENCES movies(movie_id) ON DELETE CASCADE,
  FOREIGN KEY (language_id) REFERENCES languages(language_id)
);
CREATE TABLE IF NOT EXISTS movie_genres (
  movie_id INT NOT NULL,
  genre_id INT NOT NULL,
  PRIMARY KEY (movie_id, genre_id),
  FOREIGN KEY (movie_id) REFERENCES movies(movie_id) ON DELETE CASCADE,
  FOREIGN KEY (genre_id) REFERENCES genres(genre_id)
);
CREATE TABLE IF NOT EXISTS movie_images (
  image_id INT AUTO_INCREMENT PRIMARY KEY,
  movie_id INT NOT NULL,
  image_url VARCHAR(255) NOT NULL,
  image_type VARCHAR(30) NOT NULL DEFAULT 'poster',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (movie_id) REFERENCES movies(movie_id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS theatre_movies (
  theatre_id INT NOT NULL,
  movie_id INT NOT NULL,
  PRIMARY KEY (theatre_id, movie_id),
  FOREIGN KEY (theatre_id) REFERENCES theatres(theatre_id) ON DELETE CASCADE,
  FOREIGN KEY (movie_id) REFERENCES movies(movie_id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS shows (
  show_id INT AUTO_INCREMENT PRIMARY KEY,
  movie_id INT NOT NULL,
  screen_id INT NOT NULL,
  show_date DATE NOT NULL,
  start_at DATETIME NOT NULL,
  end_at DATETIME NOT NULL,
  price DECIMAL(8,2) NOT NULL,
  slot_no TINYINT,
  is_active TINYINT(1) NOT NULL DEFAULT 1,
  INDEX idx_show_lookup (movie_id, screen_id, show_date),
  INDEX idx_show_screen_time (screen_id, start_at, end_at),
  FOREIGN KEY (movie_id) REFERENCES movies(movie_id) ON DELETE CASCADE,
  FOREIGN KEY (screen_id) REFERENCES screens(screen_id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS bookings (
  booking_id INT AUTO_INCREMENT PRIMARY KEY,
  booking_code VARCHAR(20) NOT NULL UNIQUE,
  user_id INT NOT NULL,
  show_id INT NOT NULL,
  total_amount DECIMAL(10,2) NOT NULL,
  status ENUM('confirmed','cancelled') NOT NULL DEFAULT 'confirmed',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  cancelled_at TIMESTAMP NULL,
  INDEX idx_booking_user (user_id),
  INDEX idx_booking_show (show_id),
  FOREIGN KEY (user_id) REFERENCES users(user_id),
  FOREIGN KEY (show_id) REFERENCES shows(show_id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS booking_seats (
  id INT AUTO_INCREMENT PRIMARY KEY,
  booking_id INT NOT NULL,
  show_id INT NOT NULL,
  seat_id INT NOT NULL,
  UNIQUE KEY uq_show_seat (show_id, seat_id),
  FOREIGN KEY (booking_id) REFERENCES bookings(booking_id) ON DELETE CASCADE,
  FOREIGN KEY (show_id) REFERENCES shows(show_id) ON DELETE CASCADE,
  FOREIGN KEY (seat_id) REFERENCES seats(seat_id)
);
CREATE TABLE IF NOT EXISTS payments (
  payment_id INT AUTO_INCREMENT PRIMARY KEY,
  booking_id INT NOT NULL,
  amount DECIMAL(10,2) NOT NULL,
  method VARCHAR(30) NOT NULL,
  status ENUM('success','refunded','failed') NOT NULL DEFAULT 'success',
  transaction_ref VARCHAR(40),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (booking_id) REFERENCES bookings(booking_id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS movie_reviews (
  review_id INT AUTO_INCREMENT PRIMARY KEY,
  customer_id INT NOT NULL,
  movie_id INT NOT NULL,
  booking_id INT,
  rating TINYINT NOT NULL,
  review_title VARCHAR(150),
  review_text TEXT,
  review_status ENUM('visible','hidden') NOT NULL DEFAULT 'visible',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_one_review (customer_id, movie_id),
  INDEX idx_review_movie (movie_id, review_status),
  FOREIGN KEY (customer_id) REFERENCES users(user_id) ON DELETE CASCADE,
  FOREIGN KEY (movie_id) REFERENCES movies(movie_id) ON DELETE CASCADE,
  FOREIGN KEY (booking_id) REFERENCES bookings(booking_id) ON DELETE SET NULL
);
