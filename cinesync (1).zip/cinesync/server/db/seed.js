// Creates the database/tables and loads master data. Safe to re-run.
require('dotenv').config();
const fs = require('fs'), path = require('path'), mysql = require('mysql2/promise'), bcrypt = require('bcryptjs');

// State/UT -> district -> cities. Starter data only; admin can add more from the Master Data page.
const S = (type, o) => ({ type, d: o });
const LOC = {
  'Andhra Pradesh': S('State', { Krishna: ['Vijayawada'], Visakhapatnam: ['Visakhapatnam'], Tirupati: ['Tirupati'], Guntur: ['Guntur'] }),
  'Arunachal Pradesh': S('State', { 'Papum Pare': ['Itanagar'] }),
  Assam: S('State', { Kamrup_Metropolitan: ['Guwahati'], Dibrugarh: ['Dibrugarh'] }),
  Bihar: S('State', { Patna: ['Patna'], Gaya: ['Gaya'] }),
  Chhattisgarh: S('State', { Raipur: ['Raipur'], Durg: ['Bhilai'] }),
  Goa: S('State', { 'North Goa': ['Panaji'], 'South Goa': ['Margao'] }),
  Gujarat: S('State', { Ahmedabad: ['Ahmedabad'], Surat: ['Surat'], Vadodara: ['Vadodara'], Rajkot: ['Rajkot'] }),
  Haryana: S('State', { Gurugram: ['Gurugram'], Faridabad: ['Faridabad'] }),
  'Himachal Pradesh': S('State', { Shimla: ['Shimla'], Kangra: ['Dharamshala'] }),
  Jharkhand: S('State', { Ranchi: ['Ranchi'], 'East Singhbhum': ['Jamshedpur'] }),
  Karnataka: S('State', { 'Bengaluru Urban': ['Bengaluru'], Mysuru: ['Mysuru'], 'Dakshina Kannada': ['Mangaluru'], Dharwad: ['Hubballi'] }),
  Kerala: S('State', { Ernakulam: ['Kochi'], Thiruvananthapuram: ['Thiruvananthapuram'], Kozhikode: ['Kozhikode'], Thrissur: ['Thrissur'] }),
  'Madhya Pradesh': S('State', { Bhopal: ['Bhopal'], Indore: ['Indore'] }),
  Maharashtra: S('State', { 'Mumbai City': ['Mumbai'], Pune: ['Pune'], Nagpur: ['Nagpur'], Nashik: ['Nashik'] }),
  Manipur: S('State', { 'Imphal West': ['Imphal'] }),
  Meghalaya: S('State', { 'East Khasi Hills': ['Shillong'] }),
  Mizoram: S('State', { Aizawl: ['Aizawl'] }),
  Nagaland: S('State', { Kohima: ['Kohima'], Dimapur: ['Dimapur'] }),
  Odisha: S('State', { Khordha: ['Bhubaneswar'], Cuttack: ['Cuttack'] }),
  Punjab: S('State', { Amritsar: ['Amritsar'], Ludhiana: ['Ludhiana'], Jalandhar: ['Jalandhar'] }),
  Rajasthan: S('State', { Jaipur: ['Jaipur'], Jodhpur: ['Jodhpur'], Udaipur: ['Udaipur'] }),
  Sikkim: S('State', { 'East Sikkim': ['Gangtok'] }),
  'Tamil Nadu': S('State', { Tiruchirappalli: ['Tiruchirappalli'], Chennai: ['Chennai'], Coimbatore: ['Coimbatore'], Madurai: ['Madurai'], Salem: ['Salem'], Tirunelveli: ['Tirunelveli'] }),
  Telangana: S('State', { Hyderabad: ['Hyderabad'], Warangal: ['Warangal'], Rangareddy: ['Secunderabad'] }),
  Tripura: S('State', { 'West Tripura': ['Agartala'] }),
  'Uttar Pradesh': S('State', { Lucknow: ['Lucknow'], Kanpur_Nagar: ['Kanpur'], Varanasi: ['Varanasi'], Agra: ['Agra'] }),
  Uttarakhand: S('State', { Dehradun: ['Dehradun'], Haridwar: ['Haridwar'] }),
  'West Bengal': S('State', { Kolkata: ['Kolkata'], Howrah: ['Howrah'], Darjeeling: ['Siliguri'] }),
  'Andaman and Nicobar Islands': S('Union Territory', { 'South Andaman': ['Port Blair'] }),
  Chandigarh: S('Union Territory', { Chandigarh: ['Chandigarh'] }),
  'Dadra and Nagar Haveli and Daman and Diu': S('Union Territory', { Daman: ['Daman'] }),
  Delhi: S('Union Territory', { 'New Delhi': ['New Delhi'], 'South Delhi': ['Saket'] }),
  'Jammu and Kashmir': S('Union Territory', { Srinagar: ['Srinagar'], Jammu: ['Jammu'] }),
  Ladakh: S('Union Territory', { Leh: ['Leh'] }),
  Lakshadweep: S('Union Territory', { Lakshadweep: ['Kavaratti'] }),
  Puducherry: S('Union Territory', { Puducherry: ['Puducherry'] })
};
const LANGS = ['Tamil','Telugu','Malayalam','Kannada','Hindi','Bengali','Marathi','Gujarati','Punjabi','Assamese','Odia','Urdu','Konkani','Manipuri (Meitei)','Kashmiri','Sindhi','Sanskrit','Dogri','Bodo','Santali','Maithili'];
const GENRES = ['Action','Comedy','Romance','Romantic Comedy','Thriller','Psychological Thriller','Horror','Drama','Crime','Mystery','Science Fiction (Sci-Fi)','Fantasy','Adventure','Animation','Family','Musical','Documentary','Historical','Biography','War','Sports','Mythology','Social Drama','Political Drama'];

(async () => {
  const c = await mysql.createConnection({ host: process.env.DB_HOST, user: process.env.DB_USER, password: process.env.DB_PASSWORD, multipleStatements: true });
  await c.query(fs.readFileSync(path.join(__dirname, 'schema.sql'), 'utf8'));
  await c.query('USE ' + (process.env.DB_NAME || 'cinesync'));
  await c.query("INSERT IGNORE INTO countries (name) VALUES ('India')");
  const [[{ country_id }]] = await c.query("SELECT country_id FROM countries WHERE name='India'");
  for (const [state, { type, d }] of Object.entries(LOC)) {
    await c.query('INSERT IGNORE INTO states (country_id,name,type) VALUES (?,?,?)', [country_id, state, type]);
    const [[{ state_id }]] = await c.query('SELECT state_id FROM states WHERE name=?', [state]);
    for (const [dist, cities] of Object.entries(d)) {
      const dn = dist.replace(/_/g, ' ');
      await c.query('INSERT IGNORE INTO districts (state_id,name) VALUES (?,?)', [state_id, dn]);
      const [[{ district_id }]] = await c.query('SELECT district_id FROM districts WHERE state_id=? AND name=?', [state_id, dn]);
      for (const city of cities) await c.query('INSERT IGNORE INTO cities (district_id,name) VALUES (?,?)', [district_id, city]);
    }
  }
  for (const l of LANGS) await c.query('INSERT IGNORE INTO languages (name) VALUES (?)', [l]);
  for (const g of GENRES) await c.query('INSERT IGNORE INTO genres (name) VALUES (?)', [g]);
  await c.query('INSERT IGNORE INTO admins (name,email,password_hash) VALUES (?,?,?)', ['Super Admin', 'admin@cinesync.in', await bcrypt.hash('Admin@123', 10)]);
  await c.query('INSERT IGNORE INTO users (name,email,phone,password_hash) VALUES (?,?,?,?)', ['Test Customer', 'customer@cinesync.in', '9876543210', await bcrypt.hash('Customer@123', 10)]);

  // Sample theatre (Tiruchirappalli) with 2 screens + seasons, so shows can be generated right away.
  const [[t]] = await c.query("SELECT COUNT(*) n FROM theatres");
  if (!t.n) {
    const [[{ city_id }]] = await c.query("SELECT city_id FROM cities WHERE name='Tiruchirappalli'");
    const [r] = await c.query('INSERT INTO theatres (name,address,city_id) VALUES (?,?,?)', ['CineSync Cinemas Trichy', 'Cantonment, Tiruchirappalli', city_id]);
    for (const n of [1, 2]) {
      const [s] = await c.query('INSERT INTO screens (theatre_id,screen_no,name,total_rows,seats_per_row,price) VALUES (?,?,?,?,?,?)', [r.insertId, n, 'Screen ' + n, 8, 12, n === 1 ? 180 : 150]);
      const seats = [];
      for (let i = 0; i < 8; i++) for (let k = 1; k <= 12; k++) seats.push([s.insertId, String.fromCharCode(65 + i), k]);
      await c.query('INSERT INTO seats (screen_id,row_label,seat_number) VALUES ?', [seats]);
    }
    const Y = new Date().getFullYear();
    const seasons = [['Monsoon', `${Y}-07-01`, `${Y}-10-31`, '10:00', '23:30'], ['Winter', `${Y}-11-01`, `${Y + 1}-02-28`, '09:00', '23:59'], ['Summer', `${Y + 1}-03-01`, `${Y + 1}-06-30`, '09:00', '23:59'], ['Monsoon', `${Y + 1}-07-01`, `${Y + 1}-10-31`, '10:00', '23:30']];
    for (const [name, a, b, o, cl] of seasons) {
      const [se] = await c.query('INSERT INTO seasons (name,start_date,end_date) VALUES (?,?,?)', [name, a, b]);
      await c.query('INSERT INTO seasonal_schedules (season_id,theatre_id,open_time,close_time) VALUES (?,?,?,?)', [se.insertId, r.insertId, o, cl]);
    }
  }
  console.log('Database ready. Admin: admin@cinesync.in / Admin@123 | Customer: customer@cinesync.in / Customer@123');
  await c.end();
})().catch((e) => { console.error('Seed failed:', e.message); process.exit(1); });
