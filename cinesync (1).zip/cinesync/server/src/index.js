require('dotenv').config();
const express = require('express'), cors = require('cors'), path = require('path');
const app = express();
app.use(cors()); app.use(express.json());
app.use('/uploads', express.static(path.join(__dirname, '..', 'uploads')));
app.use('/api', require('./routes/public'));
app.use('/api/admin', require('./routes/admin'));
app.use((err, req, res, next) => {
  if (err.code === 'ER_DUP_ENTRY') return res.status(409).json({ error: 'Duplicate entry: this record already exists' });
  if (err.code === 'ER_ROW_IS_REFERENCED_2') return res.status(409).json({ error: 'Cannot delete: record is in use' });
  if (!err.status) console.error(err);
  res.status(err.status || 500).json({ error: err.status ? err.message : 'Server error: ' + err.message });
});
const port = process.env.PORT || 5000;
app.listen(port, () => console.log(`CineSync API running on http://localhost:${port}`));
