const jwt = require('jsonwebtoken');
const SECRET = process.env.JWT_SECRET || 'dev-secret';
exports.sign = (p) => jwt.sign(p, SECRET, { expiresIn: '7d' });
exports.ah = (fn) => (req, res, next) => fn(req, res, next).catch(next);
exports.httpError = (status, message) => Object.assign(new Error(message), { status });
exports.auth = (role) => (req, res, next) => {
  const h = req.headers.authorization || '';
  try {
    const p = jwt.verify(h.replace('Bearer ', ''), SECRET);
    if (p.role !== role) return res.status(403).json({ error: 'Access denied' });
    req.user = p; next();
  } catch { res.status(401).json({ error: 'Please log in' }); }
};
exports.MOVIE_COLS = `m.movie_id, m.title, m.description, m.duration_min, m.release_date, m.available_from, m.available_to,
 m.certification, m.cast_crew, m.poster_url,
 (SELECT GROUP_CONCAT(CONCAT(g.genre_id,':',g.name) SEPARATOR '|') FROM movie_genres mg JOIN genres g ON g.genre_id=mg.genre_id WHERE mg.movie_id=m.movie_id) AS genres,
 (SELECT GROUP_CONCAT(CONCAT(l.language_id,':',l.name,':',ml.version_type) SEPARATOR '|') FROM movie_languages ml JOIN languages l ON l.language_id=ml.language_id WHERE ml.movie_id=m.movie_id) AS languages,
 (SELECT ROUND(AVG(r.rating),1) FROM movie_reviews r WHERE r.movie_id=m.movie_id AND r.review_status='visible') AS avg_rating,
 (SELECT COUNT(*) FROM movie_reviews r WHERE r.movie_id=m.movie_id AND r.review_status='visible') AS review_count`;
exports.parseMovie = (r) => ({
  ...r,
  genres: (r.genres || '').split('|').filter(Boolean).map((s) => { const [id, ...n] = s.split(':'); return { id: +id, name: n.join(':') }; }),
  languages: (r.languages || '').split('|').filter(Boolean).map((s) => { const [id, name, type] = s.split(':'); return { id: +id, name, type }; }),
  avg_rating: r.avg_rating === null ? null : Number(r.avg_rating)
});
