const router = require('express').Router();
const multer = require('multer'), path = require('path'), fs = require('fs');
const db = require('../db');
const { ah, auth, httpError, MOVIE_COLS, parseMovie } = require('../lib');
const { planDay, hasOverlap, dateRange, fmt, at, CLEAN_MIN } = require('../shows');
router.use(auth('admin'));

const upload = multer({
  storage: multer.diskStorage({
    destination: path.join(__dirname, '..', '..', 'uploads'),
    filename: (r, f, cb) => cb(null, Date.now() + '-' + Math.round(Math.random() * 1e6) + path.extname(f.originalname).toLowerCase())
  }),
  fileFilter: (r, f, cb) => cb(/^image\/(jpeg|png|webp|gif)$/.test(f.mimetype) ? null : httpError(400, 'Poster must be a JPG, PNG, WEBP or GIF image'), /^image\//.test(f.mimetype)),
  limits: { fileSize: 5 * 1024 * 1024 }
});
const J = (v) => { try { return JSON.parse(v || '[]'); } catch { return []; } };
const need = (o, ...keys) => keys.forEach((k) => { if (o[k] === undefined || o[k] === '') throw httpError(400, `${k} is required`); });

// ---------- Master data ----------
router.post('/districts', ah(async (q, res) => { need(q.body, 'stateId', 'name'); await db.query('INSERT INTO districts (state_id,name) VALUES (?,?)', [q.body.stateId, q.body.name.trim()]); res.json({ ok: true }); }));
router.post('/cities', ah(async (q, res) => { need(q.body, 'districtId', 'name'); await db.query('INSERT INTO cities (district_id,name) VALUES (?,?)', [q.body.districtId, q.body.name.trim()]); res.json({ ok: true }); }));
router.post('/languages', ah(async (q, res) => { need(q.body, 'name'); await db.query('INSERT INTO languages (name) VALUES (?)', [q.body.name.trim()]); res.json({ ok: true }); }));
router.post('/genres', ah(async (q, res) => { need(q.body, 'name'); await db.query('INSERT INTO genres (name) VALUES (?)', [q.body.name.trim()]); res.json({ ok: true }); }));

// ---------- Theatres & screens ----------
router.get('/theatres', ah(async (req, res) => {
  const [t] = await db.query(`SELECT t.theatre_id,t.name,t.address,c.city_id,c.name city,d.district_id,d.name district,st.state_id,st.name state
    FROM theatres t JOIN cities c ON c.city_id=t.city_id JOIN districts d ON d.district_id=c.district_id JOIN states st ON st.state_id=d.state_id ORDER BY st.name,c.name,t.name`);
  const [s] = await db.query('SELECT * FROM screens ORDER BY screen_no');
  res.json(t.map((x) => ({ ...x, screens: s.filter((y) => y.theatre_id === x.theatre_id) })));
}));
router.post('/theatres', ah(async (q, res) => { need(q.body, 'name', 'cityId'); await db.query('INSERT INTO theatres (name,address,city_id) VALUES (?,?,?)', [q.body.name, q.body.address || '', q.body.cityId]); res.json({ ok: true }); }));
router.put('/theatres/:id', ah(async (q, res) => { need(q.body, 'name', 'cityId'); await db.query('UPDATE theatres SET name=?,address=?,city_id=? WHERE theatre_id=?', [q.body.name, q.body.address || '', q.body.cityId, q.params.id]); res.json({ ok: true }); }));
router.delete('/theatres/:id', ah(async (q, res) => {
  const [[b]] = await db.query(`SELECT COUNT(*) n FROM bookings b JOIN shows s ON s.show_id=b.show_id JOIN screens sc ON sc.screen_id=s.screen_id WHERE sc.theatre_id=?`, [q.params.id]);
  if (b.n) throw httpError(409, 'Theatre has bookings and cannot be deleted');
  await db.query('DELETE FROM theatres WHERE theatre_id=?', [q.params.id]); res.json({ ok: true });
}));
router.post('/theatres/:id/screens', ah(async (req, res) => {
  const { screenNo, name, totalRows, seatsPerRow, price } = req.body; need(req.body, 'screenNo', 'totalRows', 'seatsPerRow', 'price');
  if (totalRows < 1 || totalRows > 26 || seatsPerRow < 1 || seatsPerRow > 40) throw httpError(400, 'Rows must be 1-26 and seats per row 1-40');
  const conn = await db.getConnection();
  try {
    await conn.beginTransaction();
    const [s] = await conn.query('INSERT INTO screens (theatre_id,screen_no,name,total_rows,seats_per_row,price) VALUES (?,?,?,?,?,?)', [req.params.id, screenNo, name || `Screen ${screenNo}`, totalRows, seatsPerRow, price]);
    const seats = [];
    for (let i = 0; i < totalRows; i++) for (let k = 1; k <= seatsPerRow; k++) seats.push([s.insertId, String.fromCharCode(65 + i), k]);
    await conn.query('INSERT INTO seats (screen_id,row_label,seat_number) VALUES ?', [seats]);
    await conn.commit(); res.json({ ok: true });
  } catch (e) { await conn.rollback(); throw e; } finally { conn.release(); }
}));
router.put('/screens/:id', ah(async (q, res) => {
  need(q.body, 'price'); await db.query('UPDATE screens SET price=?,name=COALESCE(?,name) WHERE screen_id=?', [q.body.price, q.body.name || null, q.params.id]);
  await db.query('UPDATE shows SET price=? WHERE screen_id=? AND start_at>NOW()', [q.body.price, q.params.id]); res.json({ ok: true });
}));
router.delete('/screens/:id', ah(async (q, res) => {
  const [[b]] = await db.query('SELECT COUNT(*) n FROM bookings b JOIN shows s ON s.show_id=b.show_id WHERE s.screen_id=?', [q.params.id]);
  if (b.n) throw httpError(409, 'Screen has bookings and cannot be deleted');
  await db.query('DELETE FROM screens WHERE screen_id=?', [q.params.id]); res.json({ ok: true });
}));

// ---------- Seasons ----------
router.get('/seasons', ah(async (req, res) => {
  const [s] = await db.query('SELECT * FROM seasons ORDER BY start_date');
  const [sch] = await db.query(`SELECT ss.*,t.name theatre,c.name city FROM seasonal_schedules ss JOIN theatres t ON t.theatre_id=ss.theatre_id JOIN cities c ON c.city_id=t.city_id`);
  res.json(s.map((x) => ({ ...x, schedules: sch.filter((y) => y.season_id === x.season_id) })));
}));
const seasonBody = (b) => { need(b, 'name', 'startDate', 'endDate'); if (b.endDate < b.startDate) throw httpError(400, 'End date must be on/after start date'); };
router.post('/seasons', ah(async (q, res) => { seasonBody(q.body); await db.query('INSERT INTO seasons (name,start_date,end_date) VALUES (?,?,?)', [q.body.name, q.body.startDate, q.body.endDate]); res.json({ ok: true }); }));
router.put('/seasons/:id', ah(async (q, res) => {
  seasonBody(q.body);
  const [clash] = await db.query(`SELECT 1 FROM seasonal_schedules a JOIN seasonal_schedules b ON a.theatre_id=b.theatre_id AND b.season_id<>a.season_id
    JOIN seasons o ON o.season_id=b.season_id WHERE a.season_id=? AND o.start_date<=? AND o.end_date>=? LIMIT 1`, [q.params.id, q.body.endDate, q.body.startDate]);
  if (clash.length) throw httpError(409, 'New dates overlap another season already assigned to one of its theatres');
  await db.query('UPDATE seasons SET name=?,start_date=?,end_date=? WHERE season_id=?', [q.body.name, q.body.startDate, q.body.endDate, q.params.id]); res.json({ ok: true });
}));
router.delete('/seasons/:id', ah(async (q, res) => { await db.query('DELETE FROM seasons WHERE season_id=?', [q.params.id]); res.json({ ok: true }); }));
router.post('/schedules', ah(async (req, res) => {
  const { seasonId, theatreIds, openTime, closeTime } = req.body; need(req.body, 'seasonId', 'openTime', 'closeTime');
  if (!theatreIds?.length) throw httpError(400, 'Select at least one theatre');
  if (openTime === closeTime) throw httpError(400, 'Opening and closing time cannot be the same');
  const [[se]] = await db.query('SELECT * FROM seasons WHERE season_id=?', [seasonId]);
  for (const tid of theatreIds) {
    const [clash] = await db.query(`SELECT se.name FROM seasonal_schedules ss JOIN seasons se ON se.season_id=ss.season_id
      WHERE ss.theatre_id=? AND ss.season_id<>? AND se.start_date<=? AND se.end_date>=? LIMIT 1`, [tid, seasonId, se.end_date, se.start_date]);
    if (clash.length) throw httpError(409, `Season dates overlap with "${clash[0].name}" for a selected theatre`);
    await db.query(`INSERT INTO seasonal_schedules (season_id,theatre_id,open_time,close_time) VALUES (?,?,?,?)
      ON DUPLICATE KEY UPDATE open_time=VALUES(open_time),close_time=VALUES(close_time)`, [seasonId, tid, openTime, closeTime]);
  }
  res.json({ ok: true });
}));
router.delete('/schedules/:id', ah(async (q, res) => { await db.query('DELETE FROM seasonal_schedules WHERE schedule_id=?', [q.params.id]); res.json({ ok: true }); }));

// ---------- Movies ----------
router.get('/movies', ah(async (req, res) => {
  const [rows] = await db.query(`SELECT ${MOVIE_COLS},(SELECT GROUP_CONCAT(tm.theatre_id) FROM theatre_movies tm WHERE tm.movie_id=m.movie_id) theatre_ids FROM movies m ORDER BY m.created_at DESC`);
  res.json(rows.map((r) => ({ ...parseMovie(r), theatre_ids: (r.theatre_ids || '').split(',').filter(Boolean).map(Number) })));
}));
const saveRelations = async (conn, id, b) => {
  need(b, 'originalLanguageId');
  await conn.query('DELETE FROM movie_languages WHERE movie_id=?', [id]);
  await conn.query("INSERT INTO movie_languages VALUES (?,?,'original')", [id, b.originalLanguageId]);
  for (const l of J(b.dubbedLanguageIds)) if (String(l) !== String(b.originalLanguageId)) await conn.query("INSERT IGNORE INTO movie_languages VALUES (?,?,'dubbed')", [id, l]);
  await conn.query('DELETE FROM movie_genres WHERE movie_id=?', [id]);
  for (const g of J(b.genreIds)) await conn.query('INSERT IGNORE INTO movie_genres VALUES (?,?)', [id, g]);
  await conn.query('DELETE FROM theatre_movies WHERE movie_id=?', [id]);
  for (const t of J(b.theatreIds)) await conn.query('INSERT IGNORE INTO theatre_movies VALUES (?,?)', [t, id]);
};
const saveMovie = (isNew) => ah(async (req, res) => {
  const b = req.body; need(b, 'title', 'durationMin', 'releaseDate');
  if (isNew && !req.file) throw httpError(400, 'Movie poster image is required');
  if (!(b.durationMin >= 30 && b.durationMin <= 400)) throw httpError(400, 'Duration must be 30-400 minutes');
  const conn = await db.getConnection();
  try {
    await conn.beginTransaction();
    const vals = [b.title, b.description || '', b.durationMin, b.releaseDate, b.availableFrom || null, b.availableTo || null, b.certification || null, b.castCrew || ''];
    let id = req.params.id;
    if (isNew) {
      const [r] = await conn.query('INSERT INTO movies (title,description,duration_min,release_date,available_from,available_to,certification,cast_crew,poster_url) VALUES (?,?,?,?,?,?,?,?,?)', [...vals, '/uploads/' + req.file.filename]);
      id = r.insertId;
    } else {
      await conn.query('UPDATE movies SET title=?,description=?,duration_min=?,release_date=?,available_from=?,available_to=?,certification=?,cast_crew=? WHERE movie_id=?', [...vals, id]);
      if (req.file) {
        const [[old]] = await conn.query('SELECT poster_url FROM movies WHERE movie_id=?', [id]);
        await conn.query('UPDATE movies SET poster_url=? WHERE movie_id=?', ['/uploads/' + req.file.filename, id]);
        if (old?.poster_url) fs.unlink(path.join(__dirname, '..', '..', old.poster_url), () => {});
      }
    }
    if (req.file) await conn.query("INSERT INTO movie_images (movie_id,image_url,image_type) VALUES (?,?,'poster')", [id, '/uploads/' + req.file.filename]);
    await saveRelations(conn, id, b);
    await conn.commit(); res.json({ ok: true, movieId: id });
  } catch (e) { await conn.rollback(); throw e; } finally { conn.release(); }
});
router.post('/movies', upload.single('poster'), saveMovie(true));
router.put('/movies/:id', upload.single('poster'), saveMovie(false));
router.delete('/movies/:id', ah(async (q, res) => {
  const [[b]] = await db.query('SELECT COUNT(*) n FROM bookings b JOIN shows s ON s.show_id=b.show_id WHERE s.movie_id=?', [q.params.id]);
  if (b.n) throw httpError(409, 'Movie has bookings. Set its "available to" date instead of deleting it.');
  await db.query('DELETE FROM movies WHERE movie_id=?', [q.params.id]); res.json({ ok: true });
}));

// ---------- Shows ----------
router.post('/shows/generate', ah(async (req, res) => {
  const { movieId, theatreId, screenId, fromDate, toDate } = req.body; need(req.body, 'movieId', 'theatreId', 'fromDate', 'toDate');
  if (toDate < fromDate) throw httpError(400, 'To date must be on/after from date');
  const [[movie]] = await db.query('SELECT * FROM movies WHERE movie_id=?', [movieId]);
  if (!movie) throw httpError(404, 'Movie not found');
  const [screens] = await db.query(`SELECT * FROM screens WHERE theatre_id=? ${screenId ? 'AND screen_id=?' : ''}`, screenId ? [theatreId, screenId] : [theatreId]);
  if (!screens.length) throw httpError(400, 'Theatre has no screens');
  await db.query('INSERT IGNORE INTO theatre_movies VALUES (?,?)', [theatreId, movieId]);
  let created = 0; const notes = new Set();
  for (const date of dateRange(fromDate, toDate)) {
    if ((movie.available_from && date < movie.available_from) || (movie.available_to && date > movie.available_to) || date < movie.release_date) { notes.add('Some dates are outside the movie availability window'); continue; }
    const [[sch]] = await db.query(`SELECT ss.open_time,ss.close_time FROM seasonal_schedules ss JOIN seasons se ON se.season_id=ss.season_id
      WHERE ss.theatre_id=? AND ? BETWEEN se.start_date AND se.end_date LIMIT 1`, [theatreId, date]);
    if (!sch) { notes.add('Some dates have no active seasonal schedule for this theatre'); continue; }
    const plan = planDay(date, sch.open_time, sch.close_time, movie.duration_min);
    if (!plan.length) notes.add('Movie is longer than the opening hours on some dates');
    for (const sc of screens) for (const p of plan) {
      if (await hasOverlap(db, sc.screen_id, p.start, p.end)) { notes.add('Some slots skipped: overlapping show already on that screen'); continue; }
      await db.query('INSERT INTO shows (movie_id,screen_id,show_date,start_at,end_at,price,slot_no) VALUES (?,?,?,?,?,?,?)', [movieId, sc.screen_id, date, p.start, p.end, sc.price, p.slot]);
      created++;
    }
  }
  res.json({ created, notes: [...notes] });
}));
router.get('/shows', ah(async (req, res) => {
  const { date, movieId, theatreId } = req.query; let w = '1=1'; const p = [];
  if (date) { w += ' AND s.show_date=?'; p.push(date); }
  if (movieId) { w += ' AND s.movie_id=?'; p.push(movieId); }
  if (theatreId) { w += ' AND t.theatre_id=?'; p.push(theatreId); }
  const [rows] = await db.query(`SELECT s.show_id,s.show_date,s.start_at,s.end_at,s.price,s.is_active,s.slot_no,m.title,m.duration_min,t.name theatre,sc.screen_no,
    sc.total_rows*sc.seats_per_row capacity,(SELECT COUNT(*) FROM booking_seats bs WHERE bs.show_id=s.show_id) booked
    FROM shows s JOIN movies m ON m.movie_id=s.movie_id JOIN screens sc ON sc.screen_id=s.screen_id JOIN theatres t ON t.theatre_id=sc.theatre_id
    WHERE ${w} ORDER BY s.start_at LIMIT 500`, p);
  res.json(rows);
}));
router.put('/shows/:id', ah(async (req, res) => {
  const [[s]] = await db.query('SELECT s.*,m.duration_min FROM shows s JOIN movies m ON m.movie_id=s.movie_id WHERE show_id=?', [req.params.id]);
  if (!s) throw httpError(404, 'Show not found');
  let { startTime, price, isActive } = req.body; let start = s.start_at, end = s.end_at;
  if (startTime) { // HH:MM on the show date (use 24:00+ style by adding days if needed via startDayOffset)
    const [h, m] = startTime.split(':').map(Number); const d = at(s.show_date, h * 60 + m + (req.body.nextDay ? 1440 : 0));
    start = fmt(d); end = fmt(new Date(d.getTime() + s.duration_min * 60000));
  }
  const active = isActive === undefined ? s.is_active : isActive ? 1 : 0;
  if (active && (await hasOverlap(db, s.screen_id, start, end, s.show_id))) throw httpError(409, 'This timing overlaps another show on the same screen');
  await db.query('UPDATE shows SET start_at=?,end_at=?,price=?,is_active=? WHERE show_id=?', [start, end, price ?? s.price, active, s.show_id]);
  res.json({ ok: true });
}));
router.delete('/shows/:id', ah(async (q, res) => {
  const [[b]] = await db.query("SELECT COUNT(*) n FROM bookings WHERE show_id=? AND status='confirmed'", [q.params.id]);
  if (b.n) throw httpError(409, 'Show has confirmed bookings. Disable it instead.');
  await db.query('DELETE FROM shows WHERE show_id=?', [q.params.id]); res.json({ ok: true });
}));

// ---------- Reviews & customers ----------
router.get('/reviews', ah(async (req, res) => {
  const { movieId, status } = req.query; let w = '1=1'; const p = [];
  if (movieId) { w += ' AND r.movie_id=?'; p.push(movieId); }
  if (status) { w += ' AND r.review_status=?'; p.push(status); }
  const [rows] = await db.query(`SELECT r.*,m.title,u.name customer,(r.booking_id IS NOT NULL) verified FROM movie_reviews r JOIN movies m ON m.movie_id=r.movie_id JOIN users u ON u.user_id=r.customer_id WHERE ${w} ORDER BY r.created_at DESC`, p);
  res.json(rows);
}));
router.put('/reviews/:id/status', ah(async (q, res) => {
  if (!['visible', 'hidden'].includes(q.body.status)) throw httpError(400, 'Invalid status');
  await db.query('UPDATE movie_reviews SET review_status=? WHERE review_id=?', [q.body.status, q.params.id]); res.json({ ok: true }); // rating itself is never editable
}));
router.get('/customers', ah(async (req, res) => {
  const [rows] = await db.query(`SELECT u.user_id,u.name,u.email,u.phone,u.created_at,
    (SELECT COUNT(*) FROM bookings b WHERE b.user_id=u.user_id AND b.status='confirmed') bookings,
    (SELECT COUNT(*) FROM bookings b WHERE b.user_id=u.user_id AND b.status='cancelled') cancelled,
    (SELECT COUNT(*) FROM booking_seats bs JOIN bookings b ON b.booking_id=bs.booking_id WHERE b.user_id=u.user_id) tickets FROM users u ORDER BY u.created_at DESC`);
  res.json(rows);
}));

// ---------- Monitoring dashboard (real DB aggregates) ----------
const BASE = `FROM shows s JOIN screens sc ON sc.screen_id=s.screen_id JOIN theatres t ON t.theatre_id=sc.theatre_id JOIN cities c ON c.city_id=t.city_id
  JOIN districts d ON d.district_id=c.district_id JOIN states st ON st.state_id=d.state_id JOIN movies m ON m.movie_id=s.movie_id`;
router.get('/stats', ah(async (req, res) => {
  const f = req.query; const w = ['1=1']; const p = [];
  [['stateId', 'st.state_id'], ['districtId', 'd.district_id'], ['cityId', 'c.city_id'], ['theatreId', 't.theatre_id'], ['movieId', 's.movie_id'], ['date', 's.show_date']]
    .forEach(([k, col]) => { if (f[k]) { w.push(`${col}=?`); p.push(f[k]); } });
  if (f.showTime) { w.push("DATE_FORMAT(s.start_at,'%H:%i')=?"); p.push(f.showTime); }
  const W = w.join(' AND ');
  const group = async (label, joins, groupBy, extra = '', order = 'tickets DESC', limit = 15) => (await db.query(
    `SELECT ${label} label,COUNT(DISTINCT b.user_id) customers,COUNT(bs.id) tickets ${BASE} ${joins}
     LEFT JOIN bookings b ON b.show_id=s.show_id AND b.status='confirmed' LEFT JOIN booking_seats bs ON bs.booking_id=b.booking_id
     WHERE ${W} ${extra} GROUP BY ${groupBy} ORDER BY ${order} LIMIT ${limit}`, p))[0];
  const one = async (sql) => (await db.query(sql, p))[0][0];
  const [{ n: customers }] = (await db.query('SELECT COUNT(*) n FROM users'))[0];
  const cap = await one(`SELECT COALESCE(SUM(sc.total_rows*sc.seats_per_row),0) capacity ${BASE} WHERE ${W} AND s.is_active=1`);
  const occ = await one(`SELECT COUNT(bs.id) tickets ${BASE} JOIN bookings b ON b.show_id=s.show_id AND b.status='confirmed' JOIN booking_seats bs ON bs.booking_id=b.booking_id WHERE ${W}`);
  const rev = await one(`SELECT COALESCE(SUM(b.total_amount),0) revenue ${BASE} JOIN bookings b ON b.show_id=s.show_id AND b.status='confirmed' WHERE ${W}`);
  const canc = await one(`SELECT COUNT(*) n ${BASE} JOIN bookings b ON b.show_id=s.show_id AND b.status='cancelled' WHERE ${W}`);
  const timeJoin = '';
  const byTime = (fmtStr, lim) => group(`DATE_FORMAT(b.created_at,'${fmtStr}')`, timeJoin, `DATE_FORMAT(b.created_at,'${fmtStr}')`, 'AND b.booking_id IS NOT NULL', 'label DESC', lim);
  const shows = (await db.query(`SELECT s.show_id,m.title,t.name theatre,sc.screen_no,s.start_at,sc.total_rows*sc.seats_per_row capacity,
    COUNT(bs.id) booked,COUNT(DISTINCT b.user_id) customers ${BASE} LEFT JOIN bookings b ON b.show_id=s.show_id AND b.status='confirmed'
    LEFT JOIN booking_seats bs ON bs.booking_id=b.booking_id WHERE ${W} GROUP BY s.show_id ORDER BY s.start_at DESC LIMIT 100`, p))[0]
    .map((r) => ({ ...r, available: r.capacity - r.booked, occupancy: r.capacity ? Math.round((r.booked / r.capacity) * 100) : 0 }));
  res.json({
    cards: { customers, tickets: occ.tickets, cancelled: canc.n, capacity: Number(cap.capacity), occupied: occ.tickets, available: Number(cap.capacity) - occ.tickets, revenue: Number(rev.revenue) },
    daily: (await byTime('%Y-%m-%d', 30)).reverse(), weekly: (await byTime('%x-W%v', 12)).reverse(), monthly: (await byTime('%Y-%m', 12)).reverse(),
    byState: await group('st.name', '', 'st.state_id'), byDistrict: await group('d.name', '', 'd.district_id'),
    byTheatre: await group('t.name', '', 't.theatre_id'), byMovie: await group('m.title', '', 'm.movie_id'),
    byLanguage: await group('l.name', "JOIN movie_languages ml ON ml.movie_id=m.movie_id AND ml.version_type='original' JOIN languages l ON l.language_id=ml.language_id", 'l.language_id'),
    byGenre: await group('g.name', 'JOIN movie_genres mg ON mg.movie_id=m.movie_id JOIN genres g ON g.genre_id=mg.genre_id', 'g.genre_id'),
    shows
  });
}));

module.exports = router;
