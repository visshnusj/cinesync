const router = require('express').Router();
const bcrypt = require('bcryptjs');
const db = require('../db');
const { sign, ah, auth, httpError, MOVIE_COLS, parseMovie } = require('../lib');
const user = auth('user');

// ---------- Auth ----------
router.post('/auth/register', ah(async (req, res) => {
  const { name, email, phone, password } = req.body;
  if (!name || !email || !password || password.length < 6) throw httpError(400, 'Name, email and a password of 6+ characters are required');
  const [r] = await db.query('INSERT INTO users (name,email,phone,password_hash) VALUES (?,?,?,?)', [name, email.toLowerCase(), phone || null, await bcrypt.hash(password, 10)]);
  res.json({ token: sign({ id: r.insertId, role: 'user' }), name, role: 'user' });
}));
const login = (table, idCol, role) => ah(async (req, res) => {
  const [[u]] = await db.query(`SELECT * FROM ${table} WHERE email=?`, [(req.body.email || '').toLowerCase()]);
  if (!u || !(await bcrypt.compare(req.body.password || '', u.password_hash))) throw httpError(401, 'Invalid email or password');
  res.json({ token: sign({ id: u[idCol], role }), name: u.name, role });
});
router.post('/auth/login', login('users', 'user_id', 'user'));
router.post('/auth/admin-login', login('admins', 'admin_id', 'admin'));

// ---------- Locations / meta ----------
router.get('/locations/states', ah(async (q, res) => res.json((await db.query('SELECT state_id,name,type FROM states ORDER BY name'))[0])));
router.get('/locations/districts', ah(async (q, res) => res.json((await db.query('SELECT district_id,name FROM districts WHERE state_id=? ORDER BY name', [q.query.stateId]))[0])));
router.get('/locations/cities', ah(async (q, res) => res.json((await db.query('SELECT city_id,name FROM cities WHERE district_id=? ORDER BY name', [q.query.districtId]))[0])));
router.get('/meta', ah(async (q, res) => {
  const [languages] = await db.query('SELECT * FROM languages ORDER BY name');
  const [genres] = await db.query('SELECT * FROM genres ORDER BY name');
  res.json({ languages, genres });
}));
router.get('/theatres', ah(async (req, res) => {
  const { stateId, districtId, cityId, q } = req.query; const p = []; let w = '1=1';
  if (stateId) { w += ' AND st.state_id=?'; p.push(stateId); }
  if (districtId) { w += ' AND d.district_id=?'; p.push(districtId); }
  if (cityId) { w += ' AND c.city_id=?'; p.push(cityId); }
  if (q) { w += ' AND (t.name LIKE ? OR c.name LIKE ? OR d.name LIKE ? OR st.name LIKE ?)'; p.push(...Array(4).fill(`%${q}%`)); }
  const [rows] = await db.query(`SELECT t.theatre_id,t.name,t.address,c.city_id,c.name city,d.name district,st.name state,
    (SELECT COUNT(*) FROM screens s WHERE s.theatre_id=t.theatre_id) screens
    FROM theatres t JOIN cities c ON c.city_id=t.city_id JOIN districts d ON d.district_id=c.district_id JOIN states st ON st.state_id=d.state_id
    WHERE ${w} ORDER BY st.name,c.name,t.name`, p);
  res.json(rows);
}));

// ---------- Movies ----------
router.get('/movies', ah(async (req, res) => {
  const { q, languageId, genreId, status, stateId, districtId, cityId, theatreId } = req.query;
  let w = '1=1'; const p = [];
  if (q) { w += ' AND m.title LIKE ?'; p.push(`%${q}%`); }
  if (languageId) { w += ' AND EXISTS (SELECT 1 FROM movie_languages x WHERE x.movie_id=m.movie_id AND x.language_id=?)'; p.push(languageId); }
  if (genreId) { w += ' AND EXISTS (SELECT 1 FROM movie_genres x WHERE x.movie_id=m.movie_id AND x.genre_id=?)'; p.push(genreId); }
  if (status === 'running') w += ' AND m.release_date<=CURDATE() AND (m.available_to IS NULL OR m.available_to>=CURDATE())';
  if (status === 'upcoming') w += ' AND m.release_date>CURDATE()';
  const loc = []; const lp = [];
  if (stateId) { loc.push('st.state_id=?'); lp.push(stateId); }
  if (districtId) { loc.push('d.district_id=?'); lp.push(districtId); }
  if (cityId) { loc.push('c.city_id=?'); lp.push(cityId); }
  if (theatreId) { loc.push('t.theatre_id=?'); lp.push(theatreId); }
  if (loc.length) {
    w += ` AND EXISTS (SELECT 1 FROM theatre_movies tm JOIN theatres t ON t.theatre_id=tm.theatre_id JOIN cities c ON c.city_id=t.city_id
      JOIN districts d ON d.district_id=c.district_id JOIN states st ON st.state_id=d.state_id WHERE tm.movie_id=m.movie_id AND ${loc.join(' AND ')})`;
    p.push(...lp);
  }
  const [rows] = await db.query(`SELECT ${MOVIE_COLS} FROM movies m WHERE ${w} ORDER BY m.release_date DESC`, p);
  res.json(rows.map(parseMovie));
}));

router.get('/movies/:id', ah(async (req, res) => {
  const [[m]] = await db.query(`SELECT ${MOVIE_COLS} FROM movies m WHERE m.movie_id=?`, [req.params.id]);
  if (!m) throw httpError(404, 'Movie not found');
  const [theatres] = await db.query(`SELECT t.theatre_id,t.name,t.address,c.name city,d.name district,st.name state FROM theatre_movies tm
    JOIN theatres t ON t.theatre_id=tm.theatre_id JOIN cities c ON c.city_id=t.city_id JOIN districts d ON d.district_id=c.district_id
    JOIN states st ON st.state_id=d.state_id WHERE tm.movie_id=? ORDER BY st.name,c.name`, [req.params.id]);
  const [dist] = await db.query("SELECT rating, COUNT(*) n FROM movie_reviews WHERE movie_id=? AND review_status='visible' GROUP BY rating", [req.params.id]);
  const distribution = { 1: 0, 2: 0, 3: 0, 4: 0, 5: 0 }; dist.forEach((d) => (distribution[d.rating] = d.n));
  res.json({ ...parseMovie(m), theatres, distribution });
}));

router.get('/movies/:id/dates', ah(async (req, res) => {
  const [rows] = await db.query(`SELECT DISTINCT s.show_date FROM shows s JOIN screens sc ON sc.screen_id=s.screen_id
    WHERE s.movie_id=? AND sc.theatre_id=? AND s.is_active=1 AND s.start_at>NOW() ORDER BY s.show_date`, [req.params.id, req.query.theatreId]);
  res.json(rows.map((r) => r.show_date));
}));

// ---------- Reviews ----------
router.get('/movies/:id/reviews', ah(async (req, res) => {
  const order = { highest: 'r.rating DESC, r.created_at DESC', lowest: 'r.rating ASC, r.created_at DESC' }[req.query.sort] || 'r.created_at DESC';
  const [rows] = await db.query(`SELECT r.review_id,r.rating,r.review_title,r.review_text,r.created_at,(r.booking_id IS NOT NULL) verified,u.name customer
    FROM movie_reviews r JOIN users u ON u.user_id=r.customer_id WHERE r.movie_id=? AND r.review_status='visible' ORDER BY ${order}`, [req.params.id]);
  res.json(rows);
}));
router.get('/movies/:id/my-review', user, ah(async (req, res) => {
  const [[r]] = await db.query('SELECT * FROM movie_reviews WHERE movie_id=? AND customer_id=?', [req.params.id, req.user.id]);
  const [[b]] = await db.query(`SELECT COUNT(*) n FROM bookings b JOIN shows s ON s.show_id=b.show_id WHERE b.user_id=? AND s.movie_id=? AND b.status='confirmed'`, [req.user.id, req.params.id]);
  res.json({ review: r || null, canReview: b.n > 0 });
}));
const checkReview = (b) => {
  const rating = Number(b.rating);
  if (!(rating >= 1 && rating <= 5)) throw httpError(400, 'Rating must be 1 to 5 stars');
  return rating;
};
router.post('/movies/:id/reviews', user, ah(async (req, res) => {
  const rating = checkReview(req.body);
  const [[b]] = await db.query(`SELECT b.booking_id FROM bookings b JOIN shows s ON s.show_id=b.show_id
    WHERE b.user_id=? AND s.movie_id=? AND b.status='confirmed' ORDER BY b.booking_id DESC LIMIT 1`, [req.user.id, req.params.id]);
  if (!b) throw httpError(403, 'Only customers with a completed booking for this movie can review it');
  await db.query('INSERT INTO movie_reviews (customer_id,movie_id,booking_id,rating,review_title,review_text) VALUES (?,?,?,?,?,?)',
    [req.user.id, req.params.id, b.booking_id, rating, req.body.title || null, req.body.text || null]);
  res.json({ ok: true });
}));
router.put('/movies/:id/reviews', user, ah(async (req, res) => {
  const rating = checkReview(req.body);
  const [r] = await db.query('UPDATE movie_reviews SET rating=?,review_title=?,review_text=? WHERE movie_id=? AND customer_id=?',
    [rating, req.body.title || null, req.body.text || null, req.params.id, req.user.id]);
  if (!r.affectedRows) throw httpError(404, 'You have no review for this movie');
  res.json({ ok: true });
}));
router.delete('/movies/:id/reviews', user, ah(async (req, res) => {
  await db.query('DELETE FROM movie_reviews WHERE movie_id=? AND customer_id=?', [req.params.id, req.user.id]);
  res.json({ ok: true });
}));

// ---------- Shows & seats ----------
router.get('/shows', ah(async (req, res) => {
  const { movieId, theatreId, date } = req.query;
  const [rows] = await db.query(`SELECT s.show_id,s.start_at,s.end_at,s.price,s.slot_no,(s.start_at<=NOW()) past,sc.screen_no,sc.name screen_name,t.name theatre,
    sc.total_rows*sc.seats_per_row capacity,(SELECT COUNT(*) FROM booking_seats bs WHERE bs.show_id=s.show_id) booked
    FROM shows s JOIN screens sc ON sc.screen_id=s.screen_id JOIN theatres t ON t.theatre_id=sc.theatre_id
    WHERE s.movie_id=? AND sc.theatre_id=? AND s.show_date=? AND s.is_active=1 ORDER BY s.start_at`, [movieId, theatreId, date]);
  res.json(rows);
}));
router.get('/shows/:id/seats', ah(async (req, res) => {
  const [[show]] = await db.query(`SELECT s.show_id,s.start_at,s.price,s.screen_id,m.title,t.name theatre,sc.screen_no FROM shows s JOIN movies m ON m.movie_id=s.movie_id
    JOIN screens sc ON sc.screen_id=s.screen_id JOIN theatres t ON t.theatre_id=sc.theatre_id WHERE s.show_id=?`, [req.params.id]);
  if (!show) throw httpError(404, 'Show not found');
  const [seats] = await db.query(`SELECT se.seat_id,se.row_label,se.seat_number,(bs.id IS NOT NULL) booked FROM seats se
    LEFT JOIN booking_seats bs ON bs.seat_id=se.seat_id AND bs.show_id=? WHERE se.screen_id=? ORDER BY se.row_label,se.seat_number`, [req.params.id, show.screen_id]);
  res.json({ show, seats });
}));

// ---------- Bookings (transactional, no double booking) ----------
router.post('/bookings', user, ah(async (req, res) => {
  const { showId, paymentMethod } = req.body; const seatIds = [...new Set(req.body.seatIds || [])];
  if (!showId || !seatIds.length || seatIds.length > 10) throw httpError(400, 'Select between 1 and 10 seats');
  const conn = await db.getConnection();
  try {
    await conn.beginTransaction();
    const [[show]] = await conn.query('SELECT show_id,screen_id,price,is_active,(start_at>NOW()) upcoming FROM shows WHERE show_id=? FOR UPDATE', [showId]);
    if (!show || !show.is_active || !show.upcoming) throw httpError(400, 'This show is not available for booking');
    const [valid] = await conn.query('SELECT seat_id FROM seats WHERE screen_id=? AND seat_id IN (?)', [show.screen_id, seatIds]);
    if (valid.length !== seatIds.length) throw httpError(400, 'Invalid seat selection');
    const [taken] = await conn.query('SELECT seat_id FROM booking_seats WHERE show_id=? AND seat_id IN (?)', [showId, seatIds]);
    if (taken.length) throw httpError(409, 'Some selected seats were just booked by someone else. Please choose again.');
    const total = Number(show.price) * seatIds.length;
    const code = 'CS' + Date.now().toString(36).toUpperCase() + Math.random().toString(36).slice(2, 6).toUpperCase();
    const [b] = await conn.query('INSERT INTO bookings (booking_code,user_id,show_id,total_amount) VALUES (?,?,?,?)', [code, req.user.id, showId, total]);
    await conn.query('INSERT INTO booking_seats (booking_id,show_id,seat_id) VALUES ?', [seatIds.map((s) => [b.insertId, showId, s])]);
    await conn.query('INSERT INTO payments (booking_id,amount,method,status,transaction_ref) VALUES (?,?,?,?,?)',
      [b.insertId, total, paymentMethod || 'UPI', 'success', 'TXN' + Date.now()]);
    await conn.commit();
    res.json({ bookingCode: code });
  } catch (e) { await conn.rollback(); throw e; } finally { conn.release(); }
}));

const BOOKING_SQL = `SELECT b.booking_id,b.booking_code,b.total_amount,b.status,b.created_at,s.show_id,s.start_at,s.movie_id,m.title,m.poster_url,
  t.name theatre,t.address,c.name city,sc.screen_no,
  (SELECT GROUP_CONCAT(CONCAT(se.row_label,se.seat_number) ORDER BY se.row_label,se.seat_number SEPARATOR ', ') FROM booking_seats bs JOIN seats se ON se.seat_id=bs.seat_id WHERE bs.booking_id=b.booking_id) seats,
  (s.start_at>NOW()) upcoming
  FROM bookings b JOIN shows s ON s.show_id=b.show_id JOIN movies m ON m.movie_id=s.movie_id JOIN screens sc ON sc.screen_id=s.screen_id
  JOIN theatres t ON t.theatre_id=sc.theatre_id JOIN cities c ON c.city_id=t.city_id WHERE b.user_id=?`;
router.get('/me/bookings', user, ah(async (req, res) => res.json((await db.query(BOOKING_SQL + ' ORDER BY b.created_at DESC', [req.user.id]))[0])));
router.get('/me/bookings/:code', user, ah(async (req, res) => {
  const [[b]] = await db.query(BOOKING_SQL + ' AND b.booking_code=?', [req.user.id, req.params.code]);
  if (!b) throw httpError(404, 'Booking not found');
  res.json(b);
}));
router.post('/me/bookings/:code/cancel', user, ah(async (req, res) => {
  const conn = await db.getConnection();
  try {
    await conn.beginTransaction();
    const [[b]] = await conn.query(`SELECT b.booking_id,b.status,(s.start_at>NOW()) upcoming FROM bookings b JOIN shows s ON s.show_id=b.show_id
      WHERE b.booking_code=? AND b.user_id=? FOR UPDATE`, [req.params.code, req.user.id]);
    if (!b) throw httpError(404, 'Booking not found');
    if (b.status !== 'confirmed' || !b.upcoming) throw httpError(400, 'This booking cannot be cancelled');
    await conn.query("UPDATE bookings SET status='cancelled',cancelled_at=NOW() WHERE booking_id=?", [b.booking_id]);
    await conn.query('DELETE FROM booking_seats WHERE booking_id=?', [b.booking_id]); // frees seats
    await conn.query("UPDATE payments SET status='refunded' WHERE booking_id=?", [b.booking_id]);
    await conn.commit(); res.json({ ok: true });
  } catch (e) { await conn.rollback(); throw e; } finally { conn.release(); }
}));
router.get('/me/profile', user, ah(async (req, res) => res.json((await db.query('SELECT user_id,name,email,phone,created_at FROM users WHERE user_id=?', [req.user.id]))[0][0])));

module.exports = router;
