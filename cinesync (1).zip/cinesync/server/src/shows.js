// Seasonal show generation: up to 5 shows/day inside the theatre's active seasonal opening hours.
const CLEAN_MIN = 20; // cleaning interval between shows
const toMin = (t) => { const [h, m] = t.split(':').map(Number); return h * 60 + m; };
const pad = (n) => String(n).padStart(2, '0');
const fmt = (d) => `${d.getUTCFullYear()}-${pad(d.getUTCMonth() + 1)}-${pad(d.getUTCDate())} ${pad(d.getUTCHours())}:${pad(d.getUTCMinutes())}:00`;
const at = (dateStr, minutes) => { const [y, m, d] = dateStr.split('-').map(Number); return new Date(Date.UTC(y, m - 1, d, 0, minutes)); };
exports.fmt = fmt; exports.at = at; exports.CLEAN_MIN = CLEAN_MIN;

exports.planDay = (dateStr, openTime, closeTime, duration) => {
  const open = toMin(openTime); let close = toMin(closeTime);
  if (close <= open) close += 1440; // closes after midnight
  const window = close - open;
  if (window < duration) return [];
  const n = Math.min(5, Math.floor((window - duration) / (duration + CLEAN_MIN)) + 1);
  const step = n > 1 ? Math.floor((window - duration) / (n - 1) / 5) * 5 : 0;
  return Array.from({ length: n }, (_, i) => {
    const start = at(dateStr, open + i * step);
    return { slot: i + 1, start: fmt(start), end: fmt(new Date(start.getTime() + duration * 60000)) };
  });
};

exports.hasOverlap = async (conn, screenId, start, end, excludeId = 0) => {
  const [r] = await conn.query(
    'SELECT show_id FROM shows WHERE screen_id=? AND show_id<>? AND is_active=1 AND start_at < ? AND end_at > ? LIMIT 1',
    [screenId, excludeId, end, start]);
  return r.length > 0;
};

exports.dateRange = (from, to) => {
  const out = []; let d = at(from, 0); const end = at(to, 0);
  while (d <= end && out.length < 366) { out.push(fmt(d).slice(0, 10)); d = new Date(d.getTime() + 86400000); }
  return out;
};
